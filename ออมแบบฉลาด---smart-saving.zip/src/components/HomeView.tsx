import React, { useState } from 'react';
import { TabType } from '../types';

interface HomeViewProps {
  onNavigate: (tab: TabType) => void;
}

interface WhySaveModalData {
  title: string;
  desc: string;
  icon: string;
  iconBg: string;
  tips: string[];
}

export const HomeView: React.FC<HomeViewProps> = ({ onNavigate }) => {
  const [activeModal, setActiveModal] = useState<WhySaveModalData | null>(null);

  const whySaveItems: {
    id: string;
    title: string;
    desc: string;
    icon: string;
    iconBg: string;
    details: WhySaveModalData;
  }[] = [
    {
      id: 'modal-1',
      title: 'มีเงินสำรอง',
      desc: 'สร้างเกราะป้องกันทางการเงินสำหรับเหตุการณ์ที่ไม่คาดคิด',
      icon: 'account_balance_wallet',
      iconBg: 'bg-[#0d6efd] text-white',
      details: {
        title: 'มีเงินสำรอง (Emergency Fund)',
        desc: 'การมีเงินสำรองฉุกเฉินอย่างน้อย 3-6 เดือนของค่าใช้จ่ายจำเป็น ช่วยให้คุณอุ่นใจเมื่อเกิดเหตุการณ์ไม่คาดฝัน เช่น เจ็บป่วย หรือต้องซ่อมแซมอุปกรณ์การเรียน',
        icon: 'account_balance_wallet',
        iconBg: 'bg-[#0d6efd] text-white',
        tips: [
          'คำนวณค่าใช้จ่ายจำเป็นรายเดือน (ค่าหอ + ค่ากิน + ค่าเดินทาง)',
          'ตั้งเป้าเก็บเงินก้อนนี้ไว้ในบัญชีดิจิทัลที่ดอกเบี้ยสูงและถอนได้คล่องตัว',
          'ห้ามนำเงินส่วนนี้ไปใช้จ่ายกับสิ่งของฟุ่มเฟือย'
        ]
      }
    },
    {
      id: 'modal-2',
      title: 'บรรลุเป้าหมาย',
      desc: 'วางแผนเพื่อซื้อของที่อยากได้ หรือเพื่อการศึกษาต่อ',
      icon: 'flag',
      iconBg: 'bg-[#00829b] text-white',
      details: {
        title: 'บรรลุเป้าหมายการเงิน (SMART Goals)',
        desc: 'การตั้งเป้าหมายการออมที่ชัดเจน ช่วยให้คุณรู้ว่าต้องเก็บเงินเท่าไหร่ และใช้เวลาเท่าใด เช่น ซื้อแท็บเล็ตเพื่อการเรียน ค่าคอร์สเพิ่มทักษะ หรือทริปพักผ่อน',
        icon: 'flag',
        iconBg: 'bg-[#00829b] text-white',
        tips: [
          'กำหนดจำนวนเงินเป้าหมายที่แน่นอน (Specific & Measurable)',
          'แบ่งเป้าหมายใหญ่ออกเป็นเป้าหมายย่อยรายเดือน (Achievable)',
          'ติดตามความคืบหน้าอย่างสม่ำเสมอผ่านแอปพลิเคชัน'
        ]
      }
    },
    {
      id: 'modal-3',
      title: 'รับมือเหตุฉุกเฉิน',
      desc: 'พร้อมรับมือกับค่าใช้จ่ายฉุกเฉินโดยไม่ต้องกู้ยืม',
      icon: 'health_and_safety',
      iconBg: 'bg-[#ba1a1a] text-white',
      details: {
        title: 'รับมือเหตุฉุกเฉินอย่างปลอดภัย',
        desc: 'ชีวิตนักศึกษามักมีรายจ่ายแทรกซ้อน การมีเงินออมส่วนนี้ช่วยให้คุณไม่ต้องพึ่งพาเงินกู้นอกระบบ บัตรกดเงินสดที่มีดอกเบี้ยสูง หรือรบกวนครอบครัวมากเกินไป',
        icon: 'health_and_safety',
        iconBg: 'bg-[#ba1a1a] text-white',
        tips: [
          'หลีกเลี่ยงการกู้ยืมเงินดอกเบี้ยสูงเพื่อใช้จ่ายชั่วคราว',
          'ตรวจสอบสิทธิ์ประกันสุขภาพนักศึกษาของมหาวิทยาลัยเพื่อลดภาระค่ารักษา',
          'สำรองเงินสดฉุกเฉินขั้นต่ำ 1,000 - 3,000 บาทติดกระเป๋าไว้เสมอ'
        ]
      }
    },
    {
      id: 'modal-4',
      title: 'สร้างอนาคตที่ดี',
      desc: 'เริ่มต้นลงทุนตั้งแต่วันนี้ เพื่อผลตอบแทนที่ยั่งยืน',
      icon: 'trending_up',
      iconBg: 'bg-[#555f6b] text-white',
      details: {
        title: 'สร้างอนาคตที่ดีด้วยดอกเบี้ยทบต้น',
        desc: 'ยิ่งเริ่มออมและเรียนรู้การลงทุนเร็วเท่าไหร่ พลังของดอกเบี้ยทบต้น (Compound Interest) จะยิ่งทำงานได้ดีขึ้น สร้างอิสรภาพทางการเงินตั้งแต่ยังเรียนไม่จบ',
        icon: 'trending_up',
        iconBg: 'bg-[#555f6b] text-white',
        tips: [
          'เวลาคือแต้มต่อที่ทรงพลังที่สุดของนักศึกษาในการลงทุน',
          'ศึกษาความรู้เรื่องกองทุนรวมดัชนี (Index Funds) และหุ้นปันผล',
          'เริ่มจากเงินหลักร้อยบาทต่อเดือนอย่างสม่ำเสมอ (DCA)'
        ]
      }
    }
  ];

  return (
    <div className="flex-grow pt-24 pb-16 px-4 md:px-8 max-w-[1240px] mx-auto w-full">
      {/* Hero Section */}
      <section className="flex flex-col lg:flex-row items-center justify-between gap-8 lg:gap-12 mb-16 lg:mb-20 min-h-[60vh]">
        <div className="flex-1 space-y-6 text-center lg:text-left">
          <div className="inline-flex items-center px-3.5 py-1.5 rounded-full bg-[#0d6efd]/10 text-[#0057cd] dark:text-[#b1c5ff] text-[12px] font-bold tracking-wider uppercase">
            <span className="material-symbols-outlined text-[16px] mr-2">trending_up</span>
            Smart Saving Platform
          </div>

          <h1 className="text-[34px] sm:text-[44px] lg:text-[52px] font-extrabold text-gradient leading-[1.15] tracking-tight">
            ออมแบบฉลาด<br />ด้วยเทคโนโลยี
          </h1>

          <p className="text-[17px] sm:text-[19px] text-[#93c5fd] max-w-xl mx-auto lg:mx-0 leading-relaxed font-normal">
            เรียนรู้การออม วางแผนการเงิน และติดตามเป้าหมายของคุณด้วยเทคโนโลยีที่ออกแบบมาเพื่อนักศึกษาโดยเฉพาะ
          </p>

          <div className="flex flex-wrap items-center justify-center lg:justify-start gap-4 pt-2">
            <button
              id="hero-start-saving-btn"
              onClick={() => onNavigate('goals')}
              className="bg-gradient-to-r from-[#2563eb] to-[#0284c7] hover:from-[#1d4ed8] hover:to-[#0369a1] text-white text-[16px] font-semibold py-3 px-6 rounded-xl shadow-lg shadow-blue-500/25 transition-all active:scale-98 flex items-center group cursor-pointer"
            >
              <span>เริ่มออมเงิน</span>
              <span className="material-symbols-outlined ml-2 group-hover:translate-x-1 transition-transform">
                arrow_forward
              </span>
            </button>

            <button
              id="hero-calc-btn"
              onClick={() => onNavigate('calculator')}
              className="bg-[#132a63] hover:bg-[#1a367c] text-[#7dd3fc] border border-[#2563eb]/50 text-[16px] font-semibold py-3 px-6 rounded-xl transition-all active:scale-98 flex items-center cursor-pointer shadow-md"
            >
              <span className="material-symbols-outlined mr-2 text-[20px] text-[#38bdf8]">calculate</span>
              <span>คำนวณเงินออม</span>
            </button>
          </div>

          {/* Quick Metrics highlight */}
          <div className="pt-4 flex items-center justify-center lg:justify-start gap-6 text-[13px] text-[#93c5fd]/90">
            <div className="flex items-center gap-1.5">
              <span className="material-symbols-outlined text-[18px] text-[#38bdf8]">check_circle</span>
              <span>ฟรีสำหรับนักศึกษา</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="material-symbols-outlined text-[18px] text-[#67e8f9]">savings</span>
              <span>ตั้งเป้าหมายได้ไม่จำกัด</span>
            </div>
          </div>
        </div>

        {/* Hero Graphic Card / Visual */}
        <div className="flex-1 w-full max-w-md relative flex items-center justify-center">
          <div className="absolute inset-0 bg-[#0057cd]/15 dark:bg-[#0057cd]/25 rounded-3xl blur-3xl -z-10" />

          {/* Styled Tech App Visual */}
          <div className="w-full bg-[#0d1e45] rounded-2xl shadow-2xl border border-[#1e429f]/50 p-6 relative overflow-hidden">
            {/* Top header bar */}
            <div className="flex items-center justify-between pb-4 border-b border-[#1e3a8a]/40">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-cyan-400" />
                <div className="w-3 h-3 rounded-full bg-blue-400" />
                <div className="w-3 h-3 rounded-full bg-indigo-400" />
              </div>
              <span className="text-[12px] font-semibold text-[#93c5fd]/70">Smart Financial Dashboard</span>
            </div>

            {/* Savings Progress Card */}
            <div className="mt-4 p-4 rounded-xl bg-gradient-to-br from-[#1d4ed8] to-[#0284c7] text-white shadow-lg shadow-blue-500/10">
              <div className="flex justify-between items-start">
                <div>
                  <span className="text-[12px] text-blue-100 font-medium">ยอดเงินออมรวมปัจจุบัน</span>
                  <h3 className="text-[28px] font-extrabold mt-0.5 text-white">฿45,200</h3>
                </div>
                <div className="p-2 bg-[#0a1b3d]/40 backdrop-blur-md rounded-lg border border-white/20">
                  <span className="material-symbols-outlined text-[24px]">account_balance_wallet</span>
                </div>
              </div>
              <div className="mt-4 space-y-1.5">
                <div className="flex justify-between text-[12px] text-blue-100">
                  <span>ความคืบหน้าภาพรวม</span>
                  <span className="font-bold">75%</span>
                </div>
                <div className="w-full bg-[#070e24]/40 rounded-full h-2 overflow-hidden">
                  <div className="bg-[#38bdf8] rounded-full h-full w-[75%]" />
                </div>
              </div>
            </div>

            {/* Mini Stat Widgets */}
            <div className="grid grid-cols-2 gap-3 mt-3">
              <div className="p-3 rounded-xl bg-[#091533] border border-[#1e429f]/40">
                <div className="flex items-center gap-2 text-[#38bdf8] mb-1">
                  <span className="material-symbols-outlined text-[18px]">local_fire_department</span>
                  <span className="text-[12px] font-semibold">Streak 14 วัน</span>
                </div>
                <p className="text-[11px] text-[#93c5fd]/70">ออมต่อเนื่องยอดเยี่ยม!</p>
              </div>

              <div className="p-3 rounded-xl bg-[#091533] border border-[#1e429f]/40">
                <div className="flex items-center gap-2 text-[#67e8f9] mb-1">
                  <span className="material-symbols-outlined text-[18px]">pie_chart</span>
                  <span className="text-[12px] font-semibold">สูตร 50-30-20</span>
                </div>
                <p className="text-[11px] text-[#93c5fd]/70">วางแผนงบประมาณ</p>
              </div>
            </div>

            {/* Target Sample */}
            <div className="mt-3 p-3 rounded-xl border border-dashed border-[#3b82f6]/40 bg-[#091533] flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-[#132a63] text-[#38bdf8] flex items-center justify-center">
                  <span className="material-symbols-outlined text-[18px]">laptop_mac</span>
                </div>
                <div>
                  <h4 className="text-[13px] font-bold text-[#e0f2fe]">แล็ปท็อปใหม่เพื่อการศึกษา</h4>
                  <p className="text-[11px] text-[#93c5fd]">฿15,000 / ฿25,000</p>
                </div>
              </div>
              <span className="text-[12px] font-bold text-[#38bdf8]">60%</span>
            </div>
          </div>
        </div>
      </section>

      {/* Why Save Section (Bento Grid) */}
      <section className="py-10">
        <div className="text-center mb-10">
          <h2 className="text-[26px] sm:text-[32px] font-bold text-[#f0f9ff] mb-3">
            ทำไมต้องออมเงิน?
          </h2>
          <p className="text-[16px] text-[#93c5fd] max-w-2xl mx-auto">
            การออมไม่ใช่แค่การเก็บเงิน แต่คือการสร้างอิสรภาพและความมั่นคงในอนาคต
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {whySaveItems.map((item) => (
            <div
              key={item.id}
              id={`why-save-card-${item.id}`}
              onClick={() => setActiveModal(item.details)}
              className="bg-[#0c1b40] border border-[#1e429f]/40 hover:border-[#38bdf8]/60 rounded-2xl p-6 cursor-pointer hover:-translate-y-1 hover:shadow-xl hover:shadow-blue-500/10 transition-all duration-300 group flex flex-col justify-between"
            >
              <div>
                <div
                  className={`w-12 h-12 rounded-xl ${item.iconBg} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform shadow-md`}
                >
                  <span className="material-symbols-outlined text-[24px]">{item.icon}</span>
                </div>
                <h3 className="text-[20px] font-bold mb-2 text-[#f0f9ff] group-hover:text-[#38bdf8] transition-colors">
                  {item.title}
                </h3>
                <p className="text-[14px] text-[#93c5fd] leading-relaxed">
                  {item.desc}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-[#1e429f]/40 flex items-center text-[13px] font-semibold text-[#38bdf8] group-hover:gap-1.5 transition-all">
                <span>อ่านรายละเอียด</span>
                <span className="material-symbols-outlined text-[16px] ml-1">arrow_forward</span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Interactive Detail Modal */}
      {activeModal && (
        <div
          id="why-save-modal"
          className="fixed inset-0 bg-[#040817]/80 backdrop-blur-sm z-[100] flex items-center justify-center p-4"
          onClick={() => setActiveModal(null)}
        >
          <div
            className="bg-[#0b193d] border border-[#1e429f]/60 rounded-2xl shadow-2xl p-6 md:p-8 max-w-lg w-full transform transition-all animate-in fade-in zoom-in-95 duration-200"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-between items-start mb-4">
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-xl ${activeModal.iconBg} flex items-center justify-center shadow-md`}>
                  <span className="material-symbols-outlined text-[22px]">{activeModal.icon}</span>
                </div>
                <h3 className="text-[20px] font-bold text-[#f0f9ff]">
                  {activeModal.title}
                </h3>
              </div>
              <button
                onClick={() => setActiveModal(null)}
                className="p-1 rounded-full text-[#93c5fd] hover:text-[#38bdf8] hover:bg-[#132a63]"
              >
                <span className="material-symbols-outlined text-[22px]">close</span>
              </button>
            </div>

            <p className="text-[15px] text-[#93c5fd] leading-relaxed mb-6">
              {activeModal.desc}
            </p>

            <div className="bg-[#070e24] border border-[#1e429f]/40 rounded-xl p-4 mb-6">
              <h4 className="text-[14px] font-bold text-[#38bdf8] mb-2 flex items-center gap-1.5">
                <span className="material-symbols-outlined text-[18px]">tips_and_updates</span>
                เคล็ดลับแนะนำสำหรับนักศึกษา
              </h4>
              <ul className="space-y-2 text-[13px] text-[#93c5fd]">
                {activeModal.tips.map((tip, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="text-[#38bdf8] font-bold">•</span>
                    <span>{tip}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="flex justify-end gap-3">
              <button
                onClick={() => {
                  setActiveModal(null);
                  onNavigate('calculator');
                }}
                className="px-4 py-2 text-[14px] font-semibold text-[#7dd3fc] hover:bg-[#132a63] rounded-lg transition-colors border border-[#1e429f]/40"
              >
                ลองคำนวณเงินออม
              </button>
              <button
                onClick={() => setActiveModal(null)}
                className="bg-gradient-to-r from-[#2563eb] to-[#0284c7] hover:from-[#1d4ed8] hover:to-[#0369a1] text-white px-5 py-2 rounded-xl text-[14px] font-semibold shadow-md transition-colors"
              >
                เข้าใจแล้ว
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
