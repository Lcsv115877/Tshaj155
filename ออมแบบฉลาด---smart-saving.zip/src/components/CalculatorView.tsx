import React, { useState, useMemo } from 'react';
import { SavingsGoal } from '../types';

interface CalculatorViewProps {
  onSaveGoal?: (goal: Omit<SavingsGoal, 'id' | 'createdAt'>) => void;
}

export const CalculatorView: React.FC<CalculatorViewProps> = ({ onSaveGoal }) => {
  const [income, setIncome] = useState<number | string>(10000);
  const [expenses, setExpenses] = useState<number | string>(6000);
  const [target, setTarget] = useState<number | string>(20000);
  const [months, setMonths] = useState<number | string>(10);
  const [goalName, setGoalName] = useState<string>('เป้าหมายใหม่');
  const [showSaveSuccess, setShowSaveSuccess] = useState<boolean>(false);

  // Numeric values
  const numIncome = Number(income) || 0;
  const numExpenses = Number(expenses) || 0;
  const numTarget = Number(target) || 0;
  const numMonths = Math.max(Number(months) || 1, 1);

  // Calculations
  const remainingIncome = Math.max(numIncome - numExpenses, 0);
  const requiredMonthlySavings = numMonths > 0 ? Math.ceil(numTarget / numMonths) : 0;
  const isFeasible = requiredMonthlySavings <= remainingIncome && remainingIncome > 0;

  // Generate chart data steps across months
  const chartSteps = useMemo(() => {
    if (numMonths <= 0 || numTarget <= 0) return [];
    
    // Choose up to 5 representative milestone months
    const stepCount = Math.min(numMonths, 5);
    const result = [];
    
    for (let i = 1; i <= stepCount; i++) {
      const monthNumber = Math.round((i / stepCount) * numMonths);
      const accumulated = Math.min(monthNumber * requiredMonthlySavings, numTarget);
      const heightPercent = numTarget > 0 ? Math.min(Math.round((accumulated / numTarget) * 100), 100) : 0;
      const isTarget = i === stepCount;
      
      result.push({
        month: monthNumber,
        label: `ด.${monthNumber}`,
        accumulated,
        heightPercent: Math.max(heightPercent, 12),
        isTarget
      });
    }
    return result;
  }, [numMonths, numTarget, requiredMonthlySavings]);

  const handleReset = () => {
    setIncome('');
    setExpenses('');
    setTarget('');
    setMonths('');
  };

  const handleQuickPreset = (inc: number, exp: number, tgt: number, m: number) => {
    setIncome(inc);
    setExpenses(exp);
    setTarget(tgt);
    setMonths(m);
  };

  const handleCreateGoal = () => {
    if (!onSaveGoal || numTarget <= 0) return;
    
    // Calculate target date by adding months to today
    const date = new Date();
    date.setMonth(date.getMonth() + numMonths);
    const formattedDate = date.toISOString().split('T')[0];

    onSaveGoal({
      name: goalName.trim() || 'เป้าหมายเงินออม',
      icon: 'savings',
      targetAmount: numTarget,
      currentAmount: 0,
      monthlySavings: requiredMonthlySavings,
      targetDate: formattedDate,
      category: 'ทั่วไป'
    });

    setShowSaveSuccess(true);
    setTimeout(() => setShowSaveSuccess(false), 3000);
  };

  return (
    <div className="flex-grow pt-24 pb-16 px-4 md:px-8 max-w-[1240px] mx-auto w-full">
      {/* Title */}
      <div className="mb-8 text-center md:text-left">
        <h1 className="text-[30px] sm:text-[36px] font-bold text-[#f0f9ff] mb-2 tracking-tight">
          เครื่องคำนวณเงินออม
        </h1>
        <p className="text-[16px] text-[#93c5fd]">
          วางแผนเป้าหมายทางการเงินของคุณได้ง่ายๆ ด้วยเครื่องมือคำนวณของเรา
        </p>
      </div>

      {/* Preset Pills */}
      <div className="mb-6 flex flex-wrap items-center gap-2">
        <span className="text-[13px] text-[#93c5fd] font-medium">ตัวอย่างแผนออม:</span>
        <button
          onClick={() => handleQuickPreset(10000, 6000, 20000, 10)}
          className="text-[12px] font-semibold px-3 py-1 bg-[#0b193d] border border-[#1e429f]/60 hover:border-[#38bdf8] rounded-full text-[#93c5fd] hover:text-[#38bdf8] transition-colors"
        >
          นักศึกษาทั่วไป (ออม ฿20,000 ใน 10 ด.)
        </button>
        <button
          onClick={() => handleQuickPreset(8000, 5500, 10000, 5)}
          className="text-[12px] font-semibold px-3 py-1 bg-[#0b193d] border border-[#1e429f]/60 hover:border-[#38bdf8] rounded-full text-[#93c5fd] hover:text-[#38bdf8] transition-colors"
        >
          ซื้อแท็บเล็ตเรียน (ออม ฿10,000 ใน 5 ด.)
        </button>
        <button
          onClick={() => handleQuickPreset(15000, 9000, 50000, 12)}
          className="text-[12px] font-semibold px-3 py-1 bg-[#0b193d] border border-[#1e429f]/60 hover:border-[#38bdf8] rounded-full text-[#93c5fd] hover:text-[#38bdf8] transition-colors"
        >
          กองทุนศึกษาต่อ (ออม ฿50,000 ใน 12 ด.)
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Calculator Inputs (5 cols) */}
        <div className="lg:col-span-5 bg-[#0b193d] rounded-2xl shadow-xl p-6 md:p-7 border border-[#1e429f]/50">
          <h2 className="text-[18px] font-bold text-[#f0f9ff] mb-5 flex items-center gap-2">
            <span className="material-symbols-outlined text-[#38bdf8]">tune</span>
            กรอกข้อมูลทางการเงิน
          </h2>

          <form className="space-y-5" onSubmit={(e) => e.preventDefault()}>
            <div>
              <label className="block text-[14px] font-bold text-[#e0f2fe] mb-2" htmlFor="calc-income">
                รายรับต่อเดือน (บาท)
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 text-[#38bdf8] font-semibold">฿</span>
                <input
                  id="calc-income"
                  type="number"
                  placeholder="เช่น 10000"
                  value={income}
                  onChange={(e) => setIncome(e.target.value)}
                  className="w-full pl-9 pr-4 py-3 rounded-xl border border-[#1e429f] bg-[#070e24] text-[#e0f2fe] placeholder-[#93c5fd]/40 focus:border-[#38bdf8] focus:ring-2 focus:ring-[#38bdf8]/20 outline-none transition-all font-medium"
                />
              </div>
            </div>

            <div>
              <label className="block text-[14px] font-bold text-[#e0f2fe] mb-2" htmlFor="calc-expenses">
                รายจ่ายคงที่ต่อเดือน (บาท)
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 text-[#38bdf8] font-semibold">฿</span>
                <input
                  id="calc-expenses"
                  type="number"
                  placeholder="เช่น 6000"
                  value={expenses}
                  onChange={(e) => setExpenses(e.target.value)}
                  className="w-full pl-9 pr-4 py-3 rounded-xl border border-[#1e429f] bg-[#070e24] text-[#e0f2fe] placeholder-[#93c5fd]/40 focus:border-[#38bdf8] focus:ring-2 focus:ring-[#38bdf8]/20 outline-none transition-all font-medium"
                />
              </div>
            </div>

            <div>
              <label className="block text-[14px] font-bold text-[#e0f2fe] mb-2" htmlFor="calc-target">
                เป้าหมายเงินออม (บาท)
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 text-[#38bdf8] font-semibold">฿</span>
                <input
                  id="calc-target"
                  type="number"
                  placeholder="เช่น 20000"
                  value={target}
                  onChange={(e) => setTarget(e.target.value)}
                  className="w-full pl-9 pr-4 py-3 rounded-xl border border-[#1e429f] bg-[#070e24] text-[#e0f2fe] placeholder-[#93c5fd]/40 focus:border-[#38bdf8] focus:ring-2 focus:ring-[#38bdf8]/20 outline-none transition-all font-medium"
                />
              </div>
            </div>

            <div>
              <label className="block text-[14px] font-bold text-[#e0f2fe] mb-2" htmlFor="calc-months">
                ระยะเวลาที่ต้องการออม (เดือน)
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 text-[#38bdf8]">
                  <span className="material-symbols-outlined text-[20px]">calendar_month</span>
                </span>
                <input
                  id="calc-months"
                  type="number"
                  placeholder="เช่น 10"
                  value={months}
                  onChange={(e) => setMonths(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 rounded-xl border border-[#1e429f] bg-[#070e24] text-[#e0f2fe] placeholder-[#93c5fd]/40 focus:border-[#38bdf8] focus:ring-2 focus:ring-[#38bdf8]/20 outline-none transition-all font-medium"
                />
              </div>
            </div>

            <div className="flex gap-3 pt-3 border-t border-[#1e429f]/40">
              <button
                type="button"
                className="flex-1 bg-gradient-to-r from-[#2563eb] to-[#0284c7] hover:from-[#1d4ed8] hover:to-[#0369a1] text-white py-3 rounded-xl font-bold shadow-md transition-all active:scale-98 cursor-pointer flex items-center justify-center gap-1.5"
              >
                <span className="material-symbols-outlined text-[18px]">calculate</span>
                คำนวณ
              </button>
              <button
                type="button"
                onClick={handleReset}
                className="flex-1 bg-[#132a63] hover:bg-[#1a367c] text-[#7dd3fc] py-3 rounded-xl font-bold border border-[#1e429f]/50 transition-all active:scale-98 cursor-pointer"
              >
                ล้างข้อมูล
              </button>
            </div>

            {/* Quick save as goal */}
            {onSaveGoal && numTarget > 0 && (
              <div className="pt-2">
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="ชื่อเป้าหมาย..."
                    value={goalName}
                    onChange={(e) => setGoalName(e.target.value)}
                    className="flex-1 px-3 py-2 text-[13px] rounded-lg border border-[#1e429f] bg-[#070e24] text-[#e0f2fe]"
                  />
                  <button
                    type="button"
                    onClick={handleCreateGoal}
                    className="px-3.5 py-2 bg-[#2563eb] hover:bg-[#1d4ed8] text-white rounded-lg text-[13px] font-semibold flex items-center gap-1 shadow-md cursor-pointer"
                  >
                    <span className="material-symbols-outlined text-[16px]">bookmark_add</span>
                    สร้างเป้าหมาย
                  </button>
                </div>
                {showSaveSuccess && (
                  <p className="text-[12px] text-[#38bdf8] mt-1.5 font-medium flex items-center gap-1">
                    <span className="material-symbols-outlined text-[14px]">check</span>
                    บันทึกไปยังหน้าเป้าหมายเรียบร้อยแล้ว!
                  </p>
                )}
              </div>
            )}
          </form>
        </div>

        {/* Results & Visualization (7 cols) */}
        <div className="lg:col-span-7 flex flex-col gap-6">
          {/* Results Cards Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Card 1: Remaining Income */}
            <div className="bg-[#0b193d] rounded-2xl p-5 border-l-4 border-[#38bdf8] border border-[#1e429f]/50 shadow-md hover:-translate-y-0.5 transition-transform">
              <p className="text-[14px] text-[#93c5fd] mb-1 font-medium">
                เงินคงเหลือหลังหักค่าใช้จ่าย
              </p>
              <h3 className="text-[26px] font-bold text-[#38bdf8]">
                ฿{remainingIncome.toLocaleString()}{' '}
                <span className="text-[14px] font-normal text-[#93c5fd]/70">
                  / เดือน
                </span>
              </h3>
              <p className="text-[12px] text-[#93c5fd]/70 mt-1">
                รายรับ ฿{numIncome.toLocaleString()} - รายจ่าย ฿{numExpenses.toLocaleString()}
              </p>
            </div>

            {/* Card 2: Required Savings */}
            <div
              className={`rounded-2xl p-5 border-l-4 shadow-md hover:-translate-y-0.5 transition-transform ${
                isFeasible
                  ? 'bg-[#0b193d] border-l-[#67e8f9] border border-[#1e429f]/50 text-[#e0f2fe]'
                  : 'bg-[#1a102b] border-l-[#f43f5e] border border-[#f43f5e]/40 text-[#fca5a5]'
              }`}
            >
              <p className="text-[14px] text-[#93c5fd] mb-1 font-medium">
                ต้องออมเดือนละ
              </p>
              <h3 className="text-[26px] font-bold text-[#f0f9ff]">
                ฿{requiredMonthlySavings.toLocaleString()}
              </h3>

              {isFeasible ? (
                <p className="text-[13px] text-[#38bdf8] mt-1 flex items-center gap-1 font-semibold">
                  <span className="material-symbols-outlined text-[18px]">check_circle</span>
                  เป็นไปได้! (น้อยกว่าเงินคงเหลือ)
                </p>
              ) : (
                <p className="text-[13px] text-[#fb7185] mt-1 flex items-center gap-1 font-semibold">
                  <span className="material-symbols-outlined text-[18px]">warning</span>
                  เกินงบ! แนะนำเพิ่มจำนวนเดือนหรือลดค่าใช้จ่าย
                </p>
              )}
            </div>
          </div>

          {/* Visualization Area */}
          <div className="bg-[#0b193d] rounded-2xl shadow-xl p-6 md:p-7 border border-[#1e429f]/50 flex-grow flex flex-col justify-between">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-[18px] font-bold text-[#f0f9ff] flex items-center gap-2">
                <span className="material-symbols-outlined text-[#38bdf8]">
                  trending_up
                </span>
                กราฟการเติบโตของเงินออม
              </h3>
              <span className="text-[12px] bg-[#132a63] border border-[#2563eb]/50 text-[#38bdf8] font-bold px-2.5 py-1 rounded-full">
                เป้าหมาย: ฿{numTarget.toLocaleString()}
              </span>
            </div>

            {/* Dynamic Bar Chart */}
            <div className="relative min-h-[260px] w-full mt-4 flex items-end gap-3 sm:gap-6 px-4 sm:px-8 pb-8 pt-10 border-l border-b border-[#1e429f]/60">
              {/* Y-axis labels */}
              <div className="absolute -left-1 sm:left-[-48px] top-0 text-[11px] font-semibold text-[#93c5fd]/70">
                ฿{(numTarget / 1000).toFixed(0)}k
              </div>
              <div className="absolute -left-1 sm:left-[-48px] top-1/2 text-[11px] font-semibold text-[#93c5fd]/70">
                ฿{(numTarget / 2000).toFixed(0)}k
              </div>
              <div className="absolute -left-1 sm:left-[-28px] bottom-6 text-[11px] font-semibold text-[#93c5fd]/70">
                0
              </div>

              {chartSteps.map((step, idx) => {
                return (
                  <div
                    key={idx}
                    className="flex-1 flex flex-col items-center justify-end h-full relative group"
                  >
                    {/* Tooltip on hover */}
                    <div className="absolute -top-12 bg-[#070e24] border border-[#1e429f] text-[#38bdf8] text-[11px] px-2.5 py-1 rounded-md opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap z-10 shadow-lg">
                      เดือนที่ {step.month}: ฿{step.accumulated.toLocaleString()}
                    </div>

                    {/* Goal reach badge */}
                    {step.isTarget && (
                      <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-gradient-to-r from-[#2563eb] to-[#0284c7] text-white text-[11px] font-bold px-2.5 py-0.5 rounded-full shadow-md whitespace-nowrap animate-bounce">
                        เป้าหมาย!
                      </div>
                    )}

                    {/* Bar */}
                    <div
                      className={`w-full rounded-t-md transition-all duration-500 cursor-pointer ${
                        step.isTarget
                          ? 'bg-gradient-to-t from-[#2563eb] to-[#38bdf8] shadow-lg shadow-blue-500/20'
                          : 'bg-[#1e3e8f]/70 hover:bg-[#2563eb]'
                      }`}
                      style={{ height: `${step.heightPercent}%` }}
                    />

                    {/* X-axis label */}
                    <span className="absolute -bottom-6 text-[12px] font-medium text-[#93c5fd]">
                      {step.label}
                    </span>
                  </div>
                );
              })}
            </div>

            {/* Smart tip banner */}
            <div className="mt-8 p-3.5 rounded-xl bg-[#070e24] border border-[#1e429f]/40 flex items-start gap-2.5 text-[13px] text-[#93c5fd]">
              <span className="material-symbols-outlined text-[18px] text-[#38bdf8] shrink-0 mt-0.5">
                tips_and_updates
              </span>
              <p>
                <strong className="text-[#38bdf8]">ข้อคิดการออม:</strong> หากคุณเก็บเงินเพิ่มเพียงวันละ <strong className="text-[#67e8f9]">฿50</strong>{' '}
                ในระยะเวลา 1 ปี คุณจะมีเงินออมเพิ่มขึ้นถึง <strong className="text-[#67e8f9]">฿18,250</strong> โดยแทบไม่กระทบการใช้ชีวิตประจำวัน!
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
