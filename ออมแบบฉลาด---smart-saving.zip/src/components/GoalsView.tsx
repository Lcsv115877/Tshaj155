import React, { useState } from 'react';
import { SavingsGoal } from '../types';

interface GoalsViewProps {
  goals: SavingsGoal[];
  onAddGoal: (goal: Omit<SavingsGoal, 'id' | 'createdAt'>) => void;
  onDepositMoney: (goalId: string, amount: number) => void;
  onDeleteGoal: (goalId: string) => void;
}

export const GoalsView: React.FC<GoalsViewProps> = ({
  goals,
  onAddGoal,
  onDepositMoney,
  onDeleteGoal,
}) => {
  // New Goal Form State
  const [name, setName] = useState('');
  const [targetAmount, setTargetAmount] = useState<number | string>('');
  const [currentAmount, setCurrentAmount] = useState<number | string>('');
  const [monthlySavings, setMonthlySavings] = useState<number | string>('');
  const [targetDate, setTargetDate] = useState('');
  const [icon, setIcon] = useState('savings');
  const [category, setCategory] = useState('ทั่วไป');

  // Deposit Modal State
  const [depositGoalId, setDepositGoalId] = useState<string | null>(null);
  const [depositAmount, setDepositAmount] = useState<number | string>('');
  const [depositSuccessMsg, setDepositSuccessMsg] = useState<string | null>(null);

  const availableIcons = [
    { id: 'savings', label: 'กระปุกออมสิน' },
    { id: 'devices', label: 'แท็บเล็ต/มือถือ' },
    { id: 'laptop_mac', label: 'คอมพิวเตอร์' },
    { id: 'flight_takeoff', label: 'ท่องเที่ยว' },
    { id: 'school', label: 'การศึกษา' },
    { id: 'directions_car', label: 'ยานพาหนะ' },
    { id: 'house', label: 'ที่อยู่อาศัย' },
    { id: 'shopping_bag', label: 'ช้อปปิ้ง' },
  ];

  const handleCreateGoal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !targetAmount) return;

    onAddGoal({
      name: name.trim(),
      icon,
      targetAmount: Number(targetAmount),
      currentAmount: Number(currentAmount) || 0,
      monthlySavings: Number(monthlySavings) || 0,
      targetDate: targetDate || new Date(Date.now() + 180 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      category,
    });

    // Reset Form
    setName('');
    setTargetAmount('');
    setCurrentAmount('');
    setMonthlySavings('');
    setTargetDate('');
  };

  const handleConfirmDeposit = () => {
    if (!depositGoalId || !depositAmount || Number(depositAmount) <= 0) return;
    onDepositMoney(depositGoalId, Number(depositAmount));
    setDepositSuccessMsg(`เพิ่มเงิน ฿${Number(depositAmount).toLocaleString()} สำเร็จแล้ว!`);
    setDepositAmount('');
    setTimeout(() => {
      setDepositGoalId(null);
      setDepositSuccessMsg(null);
    }, 1500);
  };

  const selectedGoalForDeposit = goals.find((g) => g.id === depositGoalId);

  return (
    <div className="flex-grow pt-24 pb-24 px-4 md:px-8 max-w-[1240px] mx-auto w-full flex flex-col gap-8 lg:flex-row">
      {/* Goal Creation Form (Left Column, 1/3) */}
      <section className="w-full lg:w-1/3 shrink-0">
        <div className="bg-[#0b193d] rounded-2xl p-6 shadow-xl border border-[#1e429f]/50 sticky top-24">
          <h2 className="text-[20px] font-bold text-[#38bdf8] mb-5 flex items-center gap-2">
            <span className="material-symbols-outlined text-[24px]">add_circle</span>
            สร้างเป้าหมายใหม่
          </h2>

          <form onSubmit={handleCreateGoal} className="flex flex-col gap-4">
            <div>
              <label className="block text-[14px] font-semibold text-[#e0f2fe] mb-1.5" htmlFor="goal-name">
                ชื่อเป้าหมาย
              </label>
              <input
                id="goal-name"
                type="text"
                required
                placeholder="เช่น ซื้อแท็บเล็ตเพื่อการศึกษา"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-[#1e429f] bg-[#070e24] text-[#e0f2fe] placeholder-[#93c5fd]/40 focus:border-[#38bdf8] focus:ring-2 focus:ring-[#38bdf8]/20 outline-none text-[15px]"
              />
            </div>

            <div>
              <label className="block text-[14px] font-semibold text-[#e0f2fe] mb-1.5" htmlFor="target-amount">
                จำนวนเงินเป้าหมาย (บาท)
              </label>
              <input
                id="target-amount"
                type="number"
                required
                placeholder="0.00"
                value={targetAmount}
                onChange={(e) => setTargetAmount(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-[#1e429f] bg-[#070e24] text-[#e0f2fe] placeholder-[#93c5fd]/40 focus:border-[#38bdf8] focus:ring-2 focus:ring-[#38bdf8]/20 outline-none text-[15px]"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[13px] font-semibold text-[#e0f2fe] mb-1.5" htmlFor="current-savings">
                  เงินออมปัจจุบัน
                </label>
                <input
                  id="current-savings"
                  type="number"
                  placeholder="0.00"
                  value={currentAmount}
                  onChange={(e) => setCurrentAmount(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-[#1e429f] bg-[#070e24] text-[#e0f2fe] placeholder-[#93c5fd]/40 focus:border-[#38bdf8] focus:ring-2 focus:ring-[#38bdf8]/20 outline-none text-[14px]"
                />
              </div>

              <div>
                <label className="block text-[13px] font-semibold text-[#e0f2fe] mb-1.5" htmlFor="monthly-savings">
                  ออมต่อเดือน
                </label>
                <input
                  id="monthly-savings"
                  type="number"
                  placeholder="0.00"
                  value={monthlySavings}
                  onChange={(e) => setMonthlySavings(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-[#1e429f] bg-[#070e24] text-[#e0f2fe] placeholder-[#93c5fd]/40 focus:border-[#38bdf8] focus:ring-2 focus:ring-[#38bdf8]/20 outline-none text-[14px]"
                />
              </div>
            </div>

            <div>
              <label className="block text-[14px] font-semibold text-[#e0f2fe] mb-1.5" htmlFor="target-date">
                วันที่คาดว่าจะสำเร็จ
              </label>
              <input
                id="target-date"
                type="date"
                value={targetDate}
                onChange={(e) => setTargetDate(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-[#1e429f] bg-[#070e24] text-[#e0f2fe] focus:border-[#38bdf8] focus:ring-2 focus:ring-[#38bdf8]/20 outline-none text-[14px]"
              />
            </div>

            {/* Icon selection */}
            <div>
              <label className="block text-[13px] font-semibold text-[#e0f2fe] mb-1.5">
                เลือกไอคอนเป้าหมาย
              </label>
              <div className="flex flex-wrap gap-2">
                {availableIcons.map((ic) => (
                  <button
                    key={ic.id}
                    type="button"
                    onClick={() => setIcon(ic.id)}
                    className={`p-2 rounded-lg border transition-all cursor-pointer ${
                      icon === ic.id
                        ? 'border-[#38bdf8] bg-[#1e429f]/50 text-[#38bdf8] shadow-md'
                        : 'border-[#1e429f]/40 bg-[#070e24] text-[#93c5fd]/70 hover:bg-[#132a63] hover:text-[#38bdf8]'
                    }`}
                    title={ic.label}
                  >
                    <span className="material-symbols-outlined text-[20px]">{ic.id}</span>
                  </button>
                ))}
              </div>
            </div>

            <button
              id="create-goal-btn"
              type="submit"
              className="mt-2 w-full bg-gradient-to-r from-[#2563eb] to-[#0284c7] hover:from-[#1d4ed8] hover:to-[#0369a1] text-white py-3 rounded-xl font-bold text-[15px] shadow-md active:scale-98 transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <span className="material-symbols-outlined text-[20px]">add_task</span>
              สร้างเป้าหมาย
            </button>
          </form>
        </div>
      </section>

      {/* Goals Display Area (Right Column, 2/3) */}
      <section className="w-full lg:w-2/3 flex flex-col gap-6">
        <header className="flex flex-col sm:flex-row sm:items-end justify-between gap-2">
          <div>
            <h1 className="text-[28px] sm:text-[32px] font-bold text-[#f0f9ff] tracking-tight">
              เป้าหมายของคุณ
            </h1>
            <p className="text-[15px] text-[#93c5fd] mt-0.5">
              ติดตามความคืบหน้าการออมของคุณอย่างใกล้ชิด
            </p>
          </div>

          <div className="text-[13px] bg-[#0b193d] border border-[#1e429f] text-[#38bdf8] px-3 py-1 rounded-full font-semibold self-start sm:self-auto">
            กำลังดำเนินการ {goals.length} รายการ
          </div>
        </header>

        {/* Goals Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {goals.map((goal) => {
            const percent = goal.targetAmount > 0 ? Math.min(Math.round((goal.currentAmount / goal.targetAmount) * 100), 100) : 0;
            const isCompleted = percent >= 100;

            return (
              <article
                key={goal.id}
                id={`goal-card-${goal.id}`}
                className="bg-[#0b193d] rounded-2xl p-5 md:p-6 shadow-md border border-[#1e429f]/50 hover:-translate-y-1 hover:border-[#38bdf8]/60 transition-all duration-300 flex flex-col justify-between"
              >
                <div>
                  <div className="flex justify-between items-start mb-3">
                    <div className="flex items-center gap-3">
                      <div className="p-2.5 bg-[#1e429f]/40 border border-[#3b82f6]/40 rounded-xl text-[#38bdf8]">
                        <span className="material-symbols-outlined text-[22px]">{goal.icon || 'flag'}</span>
                      </div>
                      <div>
                        <h3 className="text-[18px] font-bold text-[#f0f9ff]">
                          {goal.name}
                        </h3>
                        {goal.targetDate && (
                          <span className="text-[11px] text-[#93c5fd]/70">
                            เป้าหมาย: {goal.targetDate}
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Delete action */}
                    <button
                      onClick={() => onDeleteGoal(goal.id)}
                      className="text-[#93c5fd]/60 hover:text-red-400 p-1 rounded-full hover:bg-[#070e24] transition-colors cursor-pointer"
                      title="ลบเป้าหมาย"
                    >
                      <span className="material-symbols-outlined text-[20px]">delete</span>
                    </button>
                  </div>

                  {/* Progress info */}
                  <div className="mb-3">
                    <div className="flex justify-between text-[13px] mb-1.5">
                      <span className="text-[#93c5fd]">ความคืบหน้า</span>
                      <span className={`font-bold ${isCompleted ? 'text-[#67e8f9]' : 'text-[#38bdf8]'}`}>
                        {percent}% {isCompleted && '🎉'}
                      </span>
                    </div>
                    <div className="w-full bg-[#070e24] h-2.5 rounded-full overflow-hidden border border-[#1e429f]/40">
                      <div
                        className={`h-full rounded-full transition-all duration-700 ${
                          isCompleted ? 'bg-[#67e8f9]' : 'bg-gradient-to-r from-[#2563eb] to-[#38bdf8]'
                        }`}
                        style={{ width: `${percent}%` }}
                      />
                    </div>
                  </div>

                  {/* Money numbers */}
                  <div className="grid grid-cols-2 gap-2 text-[13px] text-[#93c5fd] mb-4 bg-[#070e24] p-2.5 rounded-xl border border-[#1e429f]/40">
                    <div>
                      <span className="block text-[11px] uppercase tracking-wider text-[#93c5fd]/70">เก็บแล้ว</span>
                      <span className="font-bold text-[#f0f9ff] text-[15px]">
                        ฿{goal.currentAmount.toLocaleString()}
                      </span>
                    </div>
                    <div className="text-right">
                      <span className="block text-[11px] uppercase tracking-wider text-[#93c5fd]/70">เป้าหมาย</span>
                      <span className="font-bold text-[#38bdf8] text-[15px]">
                        ฿{goal.targetAmount.toLocaleString()}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Card Action Button */}
                <div className="pt-2 border-t border-[#1e429f]/40 flex gap-2">
                  <button
                    onClick={() => {
                      setDepositGoalId(goal.id);
                      setDepositAmount('');
                    }}
                    className="flex-1 bg-[#132a63] hover:bg-[#1a367c] text-[#38bdf8] py-2 rounded-xl text-[14px] font-semibold border border-[#2563eb]/50 transition-colors flex items-center justify-center gap-1.5 cursor-pointer active:scale-98"
                  >
                    <span className="material-symbols-outlined text-[18px]">add_circle</span>
                    <span>เพิ่มเงิน</span>
                  </button>
                </div>
              </article>
            );
          })}
        </div>
      </section>

      {/* Deposit Money Modal */}
      {depositGoalId && selectedGoalForDeposit && (
        <div
          className="fixed inset-0 bg-black/70 backdrop-blur-xs z-[100] flex items-center justify-center p-4"
          onClick={() => setDepositGoalId(null)}
        >
          <div
            className="bg-[#0b193d] border border-[#1e429f] rounded-2xl shadow-2xl p-6 max-w-md w-full animate-in fade-in zoom-in-95 duration-200"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-between items-center mb-4">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-[#1e429f]/40 text-[#38bdf8] rounded-xl border border-[#3b82f6]/40">
                  <span className="material-symbols-outlined text-[22px]">savings</span>
                </div>
                <div>
                  <h3 className="font-bold text-[18px] text-[#f0f9ff]">
                    ฝากเงินเข้าเป้าหมาย
                  </h3>
                  <p className="text-[12px] text-[#93c5fd]">{selectedGoalForDeposit.name}</p>
                </div>
              </div>
              <button
                onClick={() => setDepositGoalId(null)}
                className="p-1 text-[#93c5fd] hover:text-[#f0f9ff] cursor-pointer"
              >
                <span className="material-symbols-outlined text-[20px]">close</span>
              </button>
            </div>

            {/* Quick deposit pills */}
            <div className="flex flex-wrap gap-2 mb-4">
              {[100, 300, 500, 1000].map((amt) => (
                <button
                  key={amt}
                  type="button"
                  onClick={() => setDepositAmount(amt)}
                  className="px-3 py-1 bg-[#070e24] hover:bg-[#132a63] border border-[#1e429f] text-[#38bdf8] rounded-lg text-[13px] font-semibold transition-colors cursor-pointer"
                >
                  +฿{amt}
                </button>
              ))}
            </div>

            <div className="mb-5">
              <label className="block text-[13px] font-semibold text-[#e0f2fe] mb-1.5">
                จำนวนเงินที่ต้องการออมเพิ่ม (บาท)
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-[#38bdf8] font-semibold">฿</span>
                <input
                  type="number"
                  placeholder="0.00"
                  value={depositAmount}
                  onChange={(e) => setDepositAmount(e.target.value)}
                  className="w-full pl-8 pr-4 py-2.5 rounded-xl border border-[#1e429f] bg-[#070e24] text-[#f0f9ff] placeholder-[#93c5fd]/40 text-[16px] font-bold outline-none focus:border-[#38bdf8] focus:ring-2 focus:ring-[#38bdf8]/20"
                />
              </div>
            </div>

            {depositSuccessMsg && (
              <div className="mb-4 p-2.5 bg-[#070e24] text-[#67e8f9] border border-[#67e8f9]/50 rounded-xl text-[13px] font-semibold flex items-center gap-2">
                <span className="material-symbols-outlined text-[18px]">check_circle</span>
                {depositSuccessMsg}
              </div>
            )}

            <div className="flex justify-end gap-2.5">
              <button
                type="button"
                onClick={() => setDepositGoalId(null)}
                className="px-4 py-2 text-[14px] font-semibold text-[#93c5fd] hover:bg-[#070e24] rounded-xl transition-colors cursor-pointer"
              >
                ยกเลิก
              </button>
              <button
                type="button"
                onClick={handleConfirmDeposit}
                className="px-5 py-2 bg-gradient-to-r from-[#2563eb] to-[#0284c7] hover:from-[#1d4ed8] hover:to-[#0369a1] text-white text-[14px] font-bold rounded-xl shadow-md transition-colors cursor-pointer"
              >
                ยืนยันการฝากเงิน
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
