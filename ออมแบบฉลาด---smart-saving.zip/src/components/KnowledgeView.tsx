import React, { useState } from 'react';
import { Article } from '../types';
import { INITIAL_ARTICLES } from '../data/initialData';

export const KnowledgeView: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('ทั้งหมด');
  const [activeArticle, setActiveArticle] = useState<Article | null>(null);

  const categories = [
    'ทั้งหมด',
    'การออม',
    'การใช้เงิน',
    'เทคโนโลยีทางการเงิน',
    'การวางแผนการเงิน',
    'การตั้งเป้าหมาย',
  ];

  const filteredArticles = INITIAL_ARTICLES.filter((art) => {
    const matchesCategory =
      selectedCategory === 'ทั้งหมด' || art.category === selectedCategory;
    const matchesSearch =
      art.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      art.summary.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="flex-grow pt-24 pb-16 px-4 md:px-8 max-w-[1240px] mx-auto w-full">
      {/* Page Header */}
      <div className="mb-8 text-center md:text-left">
        <h1 className="text-[30px] sm:text-[36px] font-bold text-[#f0f9ff] mb-2 tracking-tight">
          คลังความรู้
        </h1>
        <p className="text-[16px] text-[#93c5fd]">
          แหล่งรวมความรู้เรื่องการเงิน เพื่อการออมที่ชาญฉลาดยิ่งขึ้น
        </p>
      </div>

      {/* Search & Category Filter Section */}
      <div className="mb-8 space-y-4">
        <div className="relative w-full max-w-xl">
          <span className="material-symbols-outlined absolute left-3.5 top-1/2 -translate-y-1/2 text-[#93c5fd]">
            search
          </span>
          <input
            type="text"
            placeholder="ค้นหาบทความ..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-11 pr-4 py-3 rounded-full border border-[#1e429f] bg-[#0b193d] text-[#f0f9ff] placeholder-[#93c5fd]/50 focus:border-[#38bdf8] focus:ring-2 focus:ring-[#38bdf8]/20 outline-none text-[15px] shadow-md"
          />
        </div>

        {/* Category Pills */}
        <div className="flex flex-wrap gap-2">
          {categories.map((cat) => {
            const isActive = selectedCategory === cat;
            return (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-4 py-1.5 rounded-full text-[13px] font-semibold transition-all cursor-pointer ${
                  isActive
                    ? 'bg-[#2563eb] text-white shadow-md border border-[#60a5fa]/50'
                    : 'bg-[#0b193d] text-[#93c5fd] border border-[#1e429f] hover:border-[#38bdf8] hover:text-[#f0f9ff]'
                }`}
              >
                {cat}
              </button>
            );
          })}
        </div>
      </div>

      {/* Articles Grid */}
      {filteredArticles.length === 0 ? (
        <div className="text-center py-16 bg-[#0b193d] rounded-2xl border border-[#1e429f]">
          <span className="material-symbols-outlined text-[48px] text-[#93c5fd] mb-2">article</span>
          <h3 className="text-[18px] font-bold text-[#f0f9ff]">ไม่พบบทความที่ค้นหา</h3>
          <p className="text-[14px] text-[#93c5fd] mt-1">ลองเปลี่ยนคำค้นหาหรือเลือกหมวดหมู่อื่นดูนะ</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredArticles.map((article) => (
            <article
              key={article.id}
              onClick={() => setActiveArticle(article)}
              className="group bg-[#0b193d] rounded-2xl border border-[#1e429f]/50 shadow-md hover:shadow-xl hover:border-[#38bdf8]/60 hover:-translate-y-1 transition-all duration-300 cursor-pointer overflow-hidden flex flex-col h-full"
            >
              <div className="h-48 w-full bg-[#070e24] relative overflow-hidden">
                <img
                  src={article.imageUrl}
                  alt={article.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-90 group-hover:opacity-100"
                />
                <span className="absolute top-3 left-3 bg-[#0b193d]/90 border border-[#1e429f] backdrop-blur-xs text-[#38bdf8] text-[11px] font-bold px-2.5 py-1 rounded-md shadow-xs">
                  {article.category}
                </span>
              </div>

              <div className="p-5 flex flex-col flex-1">
                <h3 className="text-[18px] font-bold text-[#f0f9ff] mb-2 group-hover:text-[#38bdf8] transition-colors leading-snug">
                  {article.title}
                </h3>
                <p className="text-[14px] text-[#93c5fd] mb-4 flex-1 line-clamp-2 leading-relaxed">
                  {article.summary}
                </p>

                <div className="flex items-center justify-between text-[12px] text-[#93c5fd]/70 pt-3 border-t border-[#1e429f]/40">
                  <div className="flex items-center gap-1">
                    <span className="material-symbols-outlined text-[16px]">schedule</span>
                    <span>อ่าน {article.readTime}</span>
                  </div>
                  <span className="font-semibold text-[#38bdf8] group-hover:translate-x-0.5 transition-transform">
                    อ่านต่อ →
                  </span>
                </div>
              </div>
            </article>
          ))}
        </div>
      )}

      {/* Article Detail Modal */}
      {activeArticle && (
        <div
          className="fixed inset-0 z-[100] bg-black/70 backdrop-blur-xs flex items-center justify-center p-4"
          onClick={() => setActiveArticle(null)}
        >
          <div
            className="bg-[#0b193d] border border-[#1e429f] w-full max-w-3xl max-h-[90vh] rounded-2xl shadow-2xl overflow-hidden flex flex-col animate-in fade-in zoom-in-95 duration-200"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="flex justify-between items-center p-5 border-b border-[#1e429f]/50">
              <span className="bg-[#1e429f]/60 text-[#38bdf8] border border-[#38bdf8]/40 text-[12px] font-bold px-3 py-1 rounded-md">
                {activeArticle.category}
              </span>
              <button
                onClick={() => setActiveArticle(null)}
                className="text-[#93c5fd] hover:text-white p-1.5 rounded-full hover:bg-[#132a63] transition-colors cursor-pointer"
              >
                <span className="material-symbols-outlined text-[22px]">close</span>
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 md:p-8 overflow-y-auto space-y-6">
              <h2 className="text-[24px] md:text-[28px] font-extrabold text-[#f0f9ff] leading-tight">
                {activeArticle.title}
              </h2>

              <div className="flex items-center gap-4 text-[13px] text-[#93c5fd]">
                <div className="flex items-center gap-1">
                  <span className="material-symbols-outlined text-[16px]">schedule</span>
                  <span>ระยะเวลาอ่าน: {activeArticle.readTime}</span>
                </div>
                <span>•</span>
                <span>เนื้อหาสำหรับนักศึกษา</span>
              </div>

              <div className="h-64 w-full bg-[#070e24] rounded-xl overflow-hidden shadow-md border border-[#1e429f]/40">
                <img
                  src={activeArticle.imageUrl}
                  alt={activeArticle.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>

              <div className="space-y-4 text-[16px] text-[#93c5fd] leading-relaxed">
                {activeArticle.content.map((paragraph, idx) => (
                  <p key={idx}>{paragraph}</p>
                ))}
              </div>

              <div className="bg-[#070e24] p-4 rounded-xl border border-[#1e429f]/50">
                <h4 className="font-bold text-[#38bdf8] text-[15px] mb-1 flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-[18px]">verified</span>
                  ข้อคิดเตือนใจ
                </h4>
                <p className="text-[13px] text-[#93c5fd]">
                  "การออมเงินไม่ได้หมายถึงการใช้ชีวิตให้ลำบากที่สุด แต่คือการใช้จ่ายอย่างรู้คุณค่าและมีเงินเหลือเพื่ออนาคต"
                </p>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-4 border-t border-[#1e429f]/50 bg-[#070e24]/80 flex justify-end gap-3">
              <button
                onClick={() => setActiveArticle(null)}
                className="bg-[#2563eb] hover:bg-[#1d4ed8] text-white px-6 py-2 rounded-xl text-[14px] font-bold shadow-md transition-colors cursor-pointer border border-[#60a5fa]/40"
              >
                เข้าใจแล้ว
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
