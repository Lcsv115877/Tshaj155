import React, { useState } from 'react';
import { TabType } from '../types';

interface TopNavProps {
  currentTab: TabType;
  onSelectTab: (tab: TabType) => void;
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
}

export const TopNav: React.FC<TopNavProps> = ({
  currentTab,
  onSelectTab,
  isDarkMode,
  onToggleDarkMode,
}) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const navItems: { id: TabType; label: string; icon: string }[] = [
    { id: 'home', label: 'หน้าแรก', icon: 'home' },
    { id: 'about', label: 'รู้จักการออม', icon: 'savings' },
    { id: 'goals', label: 'เป้าหมาย', icon: 'flag' },
    { id: 'calculator', label: 'เครื่องคำนวณ', icon: 'calculate' },
    { id: 'dashboard', label: 'Dashboard', icon: 'dashboard' },
    { id: 'knowledge', label: 'ความรู้', icon: 'menu_book' },
    { id: 'quiz', label: 'แบบทดสอบ', icon: 'quiz' },
    { id: 'profile', label: 'โปรไฟล์', icon: 'person' },
  ];

  return (
    <>
      <header
        id="top-nav"
        className="fixed top-0 left-0 right-0 w-full z-50 bg-[#0a1532]/90 backdrop-blur-md border-b border-[#1e429f]/40 shadow-lg transition-all duration-300"
      >
        <div className="flex justify-between items-center h-16 px-4 md:px-8 max-w-[1240px] mx-auto">
          {/* Logo */}
          <div
            id="brand-logo"
            onClick={() => onSelectTab('home')}
            className="flex items-center gap-2 cursor-pointer select-none group"
          >
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#1d4ed8] to-[#0284c7] text-white flex items-center justify-center shadow-md shadow-blue-500/20 group-hover:scale-105 transition-transform">
              <span className="material-symbols-outlined text-[22px]">savings</span>
            </div>
            <div className="flex flex-col">
              <span className="text-[20px] font-bold text-[#60a5fa] leading-none tracking-tight">
                ออมแบบฉลาด
              </span>
              <span className="text-[10px] text-[#93c5fd] font-medium tracking-wide">
                Smart Saving Platform
              </span>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center space-x-1 xl:space-x-2">
            {navItems.map((item) => {
              const isActive = currentTab === item.id;
              return (
                <button
                  key={item.id}
                  id={`nav-item-${item.id}`}
                  onClick={() => onSelectTab(item.id)}
                  className={`px-3 py-1.5 rounded-lg text-[15px] font-medium transition-all duration-200 relative ${
                    isActive
                      ? 'text-[#38bdf8] font-bold after:content-[""] after:absolute after:bottom-0 after:left-3 after:right-3 after:h-[2px] after:bg-[#38bdf8]'
                      : 'text-[#93c5fd]/80 hover:text-[#38bdf8] hover:bg-[#132a63]/60'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* Actions: Dark mode toggle & mobile hamburger */}
          <div className="flex items-center gap-2">
            <button
              id="theme-toggle-btn"
              aria-label="Toggle Dark Mode"
              onClick={onToggleDarkMode}
              className="p-2 rounded-full text-[#93c5fd] hover:text-[#38bdf8] hover:bg-[#132a63] transition-colors active:scale-95"
              title={isDarkMode ? 'โหมดมืด (เปิดอยู่)' : 'โหมดสีน้ำเงินเข้ม'}
            >
              <span className="material-symbols-outlined text-[22px]">
                {isDarkMode ? 'dark_mode' : 'brightness_4'}
              </span>
            </button>

            {/* Mobile menu button */}
            <button
              id="mobile-menu-btn"
              aria-label="Open Mobile Menu"
              onClick={() => setIsMobileMenuOpen(true)}
              className="lg:hidden p-2 rounded-full text-[#38bdf8] hover:bg-[#132a63] transition-colors active:scale-95"
            >
              <span className="material-symbols-outlined text-[24px]">menu</span>
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Drawer Navigation */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 z-[100] lg:hidden flex">
          {/* Backdrop */}
          <div
            className="fixed inset-0 bg-[#060d1f]/80 backdrop-blur-sm transition-opacity"
            onClick={() => setIsMobileMenuOpen(false)}
          />

          {/* Drawer content */}
          <div className="relative w-[280px] max-w-[80vw] bg-[#0b193d] text-[#e0f2fe] h-full shadow-2xl flex flex-col z-10 animate-in slide-in-from-left duration-200 border-r border-[#1e429f]/40">
            <div className="p-4 border-b border-[#1e429f]/40 flex justify-between items-center bg-[#070e24]">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-[#1d4ed8] to-[#0284c7] text-white flex items-center justify-center">
                  <span className="material-symbols-outlined text-[18px]">savings</span>
                </div>
                <div>
                  <h3 className="font-bold text-[#38bdf8] text-[16px]">ออมแบบฉลาด</h3>
                  <p className="text-[11px] text-[#93c5fd]">Smart Saving Platform</p>
                </div>
              </div>
              <button
                onClick={() => setIsMobileMenuOpen(false)}
                className="p-1 rounded-full text-[#93c5fd] hover:bg-[#132a63]"
              >
                <span className="material-symbols-outlined text-[20px]">close</span>
              </button>
            </div>

            <div className="p-3 flex-1 overflow-y-auto space-y-1">
              {navItems.map((item) => {
                const isActive = currentTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      onSelectTab(item.id);
                      setIsMobileMenuOpen(false);
                    }}
                    className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-left text-[15px] font-medium transition-all ${
                      isActive
                        ? 'bg-[#1e3e8f] text-[#38bdf8] font-bold border border-[#3b82f6]/40'
                        : 'text-[#93c5fd]/90 hover:bg-[#132a63] hover:text-[#38bdf8]'
                    }`}
                  >
                    <span className="material-symbols-outlined text-[20px]">{item.icon}</span>
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </div>

            <div className="p-4 border-t border-[#1e429f]/40 bg-[#070e24]">
              <button
                onClick={() => {
                  onSelectTab('goals');
                  setIsMobileMenuOpen(false);
                }}
                className="w-full bg-gradient-to-r from-[#1d4ed8] to-[#0284c7] hover:from-[#1e40af] hover:to-[#0369a1] text-white py-2.5 rounded-xl text-sm font-semibold shadow-md flex items-center justify-center gap-2"
              >
                <span className="material-symbols-outlined text-[18px]">add_circle</span>
                เริ่มออมวันนี้
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
