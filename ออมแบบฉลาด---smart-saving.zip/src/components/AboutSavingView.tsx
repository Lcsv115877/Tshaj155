import React, { useState } from 'react';
import { TabType } from '../types';

interface AboutSavingViewProps {
  onNavigate: (tab: TabType) => void;
}

export const AboutSavingView: React.FC<AboutSavingViewProps> = ({ onNavigate }) => {
  const [monthlyAllowance, setMonthlyAllowance] = useState<number>(10000);
  const [years, setYears] = useState<number>(10);
  const [monthlyInvest, setMonthlyInvest] = useState<number>(1000);
  const [expectedReturn, setExpectedReturn] = useState<number>(7);

  // 50/30/20 calculation
  const needs = Math.round(monthlyAllowance * 0.5);
  const wants = Math.round(monthlyAllowance * 0.3);
  const savings = Math.round(monthlyAllowance * 0.2);

  // Compound Interest Calculation: FV = P * [ ((1 + r/n)^(nt) - 1) / (r/n) ]
  const r = expectedReturn / 100 / 12;
  const n = years * 12;
  const futureValue = r > 0 ? Math.round(monthlyInvest * ((Math.pow(1 + r, n) - 1) / r)) : monthlyInvest * n;
  const totalPrincipal = monthlyInvest * n;
  const totalInterest = Math.max(futureValue - totalPrincipal, 0);

  return (
    <div className="flex-grow pt-24 pb-16 px-4 md:px-8 max-w-[1240px] mx-auto w-full space-y-12">
      {/* Header */}
      <header className="text-center max-w-2xl mx-auto">
        <div className="inline-flex items-center px-3.5 py-1.5 rounded-full bg-[#1e429f]/30 border border-[#3b82f6]/40 text-[#38bdf8] text-[12px] font-bold tracking-wider uppercase mb-3">
          <span className="material-symbols-outlined text-[16px] mr-1.5">school</span>
          คู่มือการเงินสำหรับนักศึกษา
        </div>
        <h1 className="text-[32px] sm:text-[40px] font-extrabold text-[#f0f9ff] mb-3 tracking-tight">
          รู้จักการออมเงินอย่างชาญฉลาด
        </h1>
        <p className="text-[16px] text-[#93c5fd]">
          สร้างรากฐานความมั่นคงทางการเงินตั้งแต่วัยเรียน เข้าใจง่าย ปฏิบัติได้จริงในชีวิตประจำวัน
        </p>
      </header>

      {/* Interactive 50/30/20 Calculator */}
      <section className="bg-[#0b193d] rounded-2xl p-6 md:p-8 shadow-xl border border-[#1e429f]/50">
        <div className="flex flex-col lg:flex-row items-start justify-between gap-8">
          <div className="flex-1 space-y-4">
            <span className="text-[12px] font-bold text-[#38bdf8] uppercase tracking-wider">
              สูตรยอดนิยมระดับโลก
            </span>
            <h2 className="text-[24px] font-bold text-[#f0f9ff]">
              สูตรการแบ่งเงิน 50 - 30 - 20
            </h2>
            <p className="text-[15px] text-[#93c5fd] leading-relaxed">
              วิธีจัดสรรเงินที่ยืดหยุ่นและช่วยให้ไม่ตึงเครียดเกินไป โดยแบ่งรายได้ออกเป็น 3 ส่วนหลักเพื่อให้ชีวิตมีความสุขและมีเงินเก็บควบคู่กัน
            </p>

            <div className="pt-2">
              <label className="block text-[14px] font-semibold text-[#e0f2fe] mb-2">
                รายรับหรือเงินค่าขนมรายเดือนของคุณ: <strong className="text-[#38bdf8]">฿{monthlyAllowance.toLocaleString()}</strong>
              </label>
              <input
                type="range"
                min="3000"
                max="30000"
                step="500"
                value={monthlyAllowance}
                onChange={(e) => setMonthlyAllowance(Number(e.target.value))}
                className="w-full h-2 bg-[#070e24] rounded-lg appearance-none cursor-pointer accent-[#38bdf8]"
              />
              <div className="flex justify-between text-[11px] text-[#93c5fd]/70 mt-1">
                <span>฿3,000</span>
                <span>฿15,000</span>
                <span>฿30,000</span>
              </div>
            </div>
          </div>

          {/* Breakdown cards */}
          <div className="w-full lg:w-[460px] grid grid-cols-1 sm:grid-cols-3 gap-3.5">
            <div className="bg-[#0f2557] border border-[#2563eb]/50 p-4 rounded-xl text-center shadow-md">
              <span className="text-[12px] font-bold text-[#60a5fa]">50% จำเป็น</span>
              <h3 className="text-[22px] font-extrabold text-[#f0f9ff] my-1">
                ฿{needs.toLocaleString()}
              </h3>
              <p className="text-[11px] text-[#93c5fd]/80">ค่าหอพัก, อาหาร, เดินทาง</p>
            </div>

            <div className="bg-[#0f2557] border border-[#38bdf8]/50 p-4 rounded-xl text-center shadow-md">
              <span className="text-[12px] font-bold text-[#38bdf8]">30% ความสุข</span>
              <h3 className="text-[22px] font-extrabold text-[#7dd3fc] my-1">
                ฿{wants.toLocaleString()}
              </h3>
              <p className="text-[11px] text-[#93c5fd]/80">สังสรรค์, ช้อปปิ้ง, เที่ยว</p>
            </div>

            <div className="bg-[#0f2557] border border-[#67e8f9]/50 p-4 rounded-xl text-center shadow-md">
              <span className="text-[12px] font-bold text-[#67e8f9]">20% เงินออม</span>
              <h3 className="text-[22px] font-extrabold text-[#a5f3fc] my-1">
                ฿{savings.toLocaleString()}
              </h3>
              <p className="text-[11px] text-[#93c5fd]/80">เงินสำรอง, อนาคต, ทุน</p>
            </div>
          </div>
        </div>
      </section>

      {/* Interactive Compound Interest Simulator */}
      <section className="bg-[#0b193d] rounded-2xl p-6 md:p-8 shadow-xl border border-[#1e429f]/50">
        <div className="text-center max-w-xl mx-auto mb-8">
          <span className="text-[12px] font-bold text-[#38bdf8] uppercase tracking-wider">
            มหัศจรรย์แห่งเวลา
          </span>
          <h2 className="text-[24px] font-bold text-[#f0f9ff] mt-1">
            จำลองพลังดอกเบี้ยทบต้น (Compound Interest)
          </h2>
          <p className="text-[14px] text-[#93c5fd] mt-1">
            ดูว่าเงินออมเล็กๆ น้อยๆ ในวัยเรียน จะเติบโตเป็นเงินก้อนใหญ่ได้อย่างไรเมื่อเวลาผ่านไป
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Controls */}
          <div className="lg:col-span-6 space-y-5">
            <div>
              <div className="flex justify-between text-[14px] font-semibold text-[#e0f2fe] mb-1.5">
                <span>ออมเดือนละ:</span>
                <span className="font-bold text-[#38bdf8]">฿{monthlyInvest.toLocaleString()}</span>
              </div>
              <input
                type="range"
                min="300"
                max="10000"
                step="100"
                value={monthlyInvest}
                onChange={(e) => setMonthlyInvest(Number(e.target.value))}
                className="w-full h-2 bg-[#070e24] rounded-lg appearance-none cursor-pointer accent-[#38bdf8]"
              />
            </div>

            <div>
              <div className="flex justify-between text-[14px] font-semibold text-[#e0f2fe] mb-1.5">
                <span>ระยะเวลา:</span>
                <span className="font-bold text-[#67e8f9]">{years} ปี</span>
              </div>
              <input
                type="range"
                min="1"
                max="30"
                value={years}
                onChange={(e) => setYears(Number(e.target.value))}
                className="w-full h-2 bg-[#070e24] rounded-lg appearance-none cursor-pointer accent-[#67e8f9]"
              />
            </div>

            <div>
              <div className="flex justify-between text-[14px] font-semibold text-[#e0f2fe] mb-1.5">
                <span>ผลตอบแทนเฉลี่ยต่อปี:</span>
                <span className="font-bold text-[#38bdf8]">{expectedReturn}%</span>
              </div>
              <input
                type="range"
                min="1"
                max="12"
                step="0.5"
                value={expectedReturn}
                onChange={(e) => setExpectedReturn(Number(e.target.value))}
                className="w-full h-2 bg-[#070e24] rounded-lg appearance-none cursor-pointer accent-[#38bdf8]"
              />
            </div>
          </div>

          {/* Results Visual */}
          <div className="lg:col-span-6 bg-[#070e24] p-6 rounded-2xl border border-[#1e429f]/50 flex flex-col justify-between shadow-inner">
            <div>
              <span className="text-[13px] text-[#93c5fd]">มูลค่าเงินสะสมในอนาคต</span>
              <h3 className="text-[34px] font-extrabold text-[#38bdf8] my-1">
                ฿{futureValue.toLocaleString()}
              </h3>
            </div>

            <div className="grid grid-cols-2 gap-4 mt-6 pt-4 border-t border-[#1e429f]/40">
              <div>
                <span className="text-[12px] text-[#93c5fd]/70">เงินต้นทั้งหมดที่ออม</span>
                <p className="text-[16px] font-bold text-[#e0f2fe]">
                  ฿{totalPrincipal.toLocaleString()}
                </p>
              </div>
              <div>
                <span className="text-[12px] text-[#67e8f9] font-semibold">ดอกเบี้ย/กำไรที่ได้</span>
                <p className="text-[16px] font-bold text-[#67e8f9]">
                  +฿{totalInterest.toLocaleString()}
                </p>
              </div>
            </div>

            <div className="mt-6 flex gap-3">
              <button
                onClick={() => onNavigate('calculator')}
                className="flex-1 bg-gradient-to-r from-[#2563eb] to-[#0284c7] hover:from-[#1d4ed8] hover:to-[#0369a1] text-white py-2.5 rounded-xl font-bold text-[14px] shadow-md text-center transition-all cursor-pointer"
              >
                คำนวณเป้าหมายจริง
              </button>
              <button
                onClick={() => onNavigate('quiz')}
                className="px-4 py-2.5 bg-[#132a63] border border-[#2563eb]/50 text-[#7dd3fc] rounded-xl font-bold text-[14px] hover:bg-[#1a367c] transition-all cursor-pointer"
              >
                ทดสอบความรู้
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
