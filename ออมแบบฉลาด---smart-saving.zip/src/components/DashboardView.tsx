import React, { useState } from 'react';
import { SavingsGoal, TabType } from '../types';
import { MONTHLY_SAVINGS_HISTORY } from '../data/initialData';

interface DashboardViewProps {
  goals: SavingsGoal[];
  onNavigate: (tab: TabType) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({ goals, onNavigate }) => {
  const [timeRange, setTimeRange] = useState<'6months' | 'year'>('6months');

  // Calculate dynamic totals from goals
  const totalGoalSavings = goals.reduce((acc, g) => acc + g.currentAmount, 0);
  const totalSavings = 45200 + (totalGoalSavings > 22750 ? totalGoalSavings - 22750 : 0);

  return (
    <div className="flex-grow pt-24 pb-16 px-4 md:px-8 max-w-[1240px] mx-auto w-full">
      {/* Header */}
      <header className="mb-8 text-center md:text-left">
        <h1 className="text-[30px] sm:text-[36px] font-bold text-[#f0f9ff] mb-2 tracking-tight">
          ภาพรวมการออมของคุณ
        </h1>
        <p className="text-[16px] text-[#93c5fd]">
          ติดตามความคืบหน้าและเป้าหมายทางการเงินของคุณ
        </p>
      </header>

      {/* 4 Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {/* Stat Card 1 */}
        <div className="bg-[#0b193d] rounded-2xl p-5 shadow-md border border-[#1e429f]/50 hover:-translate-y-1 transition-transform duration-300">
          <div className="flex justify-between items-start mb-3">
            <div>
              <p className="text-[13px] text-[#93c5fd] mb-1 font-medium">
                ยอดเงินออมรวม
              </p>
              <h3 className="text-[26px] font-bold text-[#f0f9ff]">
                ฿{totalSavings.toLocaleString()}
              </h3>
            </div>
            <div className="p-2.5 bg-[#1e429f]/40 border border-[#3b82f6]/40 text-[#38bdf8] rounded-xl">
              <span className="material-symbols-outlined text-[22px]">account_balance</span>
            </div>
          </div>
          <div className="flex items-center text-[#67e8f9] text-[12px] font-bold">
            <span className="material-symbols-outlined text-[16px] mr-1">trending_up</span>
            <span>+12% จากเดือนที่แล้ว</span>
          </div>
        </div>

        {/* Stat Card 2 */}
        <div className="bg-[#0b193d] rounded-2xl p-5 shadow-md border border-[#1e429f]/50 hover:-translate-y-1 transition-transform duration-300">
          <div className="flex justify-between items-start mb-3">
            <div>
              <p className="text-[13px] text-[#93c5fd] mb-1 font-medium">
                ออมเดือนนี้
              </p>
              <h3 className="text-[26px] font-bold text-[#f0f9ff]">
                ฿3,500
              </h3>
            </div>
            <div className="p-2.5 bg-[#1e429f]/40 border border-[#3b82f6]/40 text-[#38bdf8] rounded-xl">
              <span className="material-symbols-outlined text-[22px]">payments</span>
            </div>
          </div>
          <div className="w-full bg-[#070e24] rounded-full h-2 mt-3 overflow-hidden border border-[#1e429f]/40">
            <div className="bg-gradient-to-r from-[#2563eb] to-[#38bdf8] h-2 rounded-full w-[70%]" />
          </div>
          <p className="text-[11px] font-bold text-[#93c5fd] mt-2 text-right">
            70% ของเป้าหมาย
          </p>
        </div>

        {/* Stat Card 3 */}
        <div className="bg-[#0b193d] rounded-2xl p-5 shadow-md border border-[#1e429f]/50 hover:-translate-y-1 transition-transform duration-300">
          <div className="flex justify-between items-start mb-3">
            <div>
              <p className="text-[13px] text-[#93c5fd] mb-1 font-medium">
                เป้าหมายที่กำลังทำ
              </p>
              <h3 className="text-[26px] font-bold text-[#f0f9ff]">
                {goals.length}{' '}
                <span className="text-[14px] font-normal text-[#93c5fd]/70">
                  เป้าหมาย
                </span>
              </h3>
            </div>
            <div className="p-2.5 bg-[#1e429f]/40 border border-[#3b82f6]/40 text-[#38bdf8] rounded-xl">
              <span className="material-symbols-outlined text-[22px]">flag</span>
            </div>
          </div>
          <p className="text-[12px] font-medium text-[#67e8f9] mt-3 flex items-center gap-1">
            <span className="material-symbols-outlined text-[16px]">check_circle</span>
            สำเร็จแล้ว 1 เป้าหมายในเดือนนี้
          </p>
        </div>

        {/* Stat Card 4 */}
        <div className="bg-[#0b193d] rounded-2xl p-5 shadow-md border border-[#1e429f]/50 hover:-translate-y-1 transition-transform duration-300">
          <div className="flex justify-between items-start mb-3">
            <div>
              <p className="text-[13px] text-[#93c5fd] mb-1 font-medium">
                ออมต่อเนื่อง (Streak)
              </p>
              <h3 className="text-[26px] font-bold text-[#f0f9ff]">
                14{' '}
                <span className="text-[14px] font-normal text-[#93c5fd]/70">
                  วัน
                </span>
              </h3>
            </div>
            <div className="p-2.5 bg-[#1e429f]/40 border border-[#38bdf8]/40 text-[#38bdf8] rounded-xl">
              <span className="material-symbols-outlined text-[22px]">local_fire_department</span>
            </div>
          </div>
          <p className="text-[12px] font-medium text-[#7dd3fc] mt-3 flex items-center gap-1">
            <span>🔥</span>
            ยอดเยี่ยม! ทำต่อไปนะ
          </p>
        </div>
      </div>

      {/* Bento Grid: Charts & Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        {/* Main Chart Area (2 cols) */}
        <div className="lg:col-span-2 bg-[#0b193d] rounded-2xl p-6 shadow-xl border border-[#1e429f]/50 flex flex-col justify-between">
          <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3 mb-6">
            <div>
              <h3 className="text-[18px] font-bold text-[#f0f9ff]">
                แนวโน้มการออมรายเดือน
              </h3>
              <p className="text-[12px] text-[#93c5fd]">เปรียบเทียบยอดสะสมแต่ละเดือน</p>
            </div>

            <select
              value={timeRange}
              onChange={(e) => setTimeRange(e.target.value as any)}
              className="bg-[#070e24] border border-[#1e429f] text-[13px] font-semibold text-[#38bdf8] rounded-xl px-3 py-1.5 focus:ring-2 focus:ring-[#38bdf8] outline-none cursor-pointer self-start sm:self-auto"
            >
              <option value="6months">6 เดือนล่าสุด</option>
              <option value="year">ปีนี้ (2025)</option>
            </select>
          </div>

          {/* Bar Chart Container */}
          <div className="h-64 w-full flex items-end justify-between gap-2 sm:gap-4 pb-4 px-2 sm:px-6 border-b border-[#1e429f]/50">
            {MONTHLY_SAVINGS_HISTORY.map((item, idx) => {
              const isCurrent = idx === MONTHLY_SAVINGS_HISTORY.length - 1;
              return (
                <div
                  key={idx}
                  className="flex-1 flex flex-col items-center justify-end h-full relative group cursor-pointer"
                >
                  {/* Tooltip */}
                  <div className="absolute -top-9 bg-[#070e24] border border-[#1e429f] text-[#38bdf8] text-[11px] font-semibold px-2.5 py-1 rounded-md opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap shadow-md z-10">
                    {item.month}: ฿{item.amount.toLocaleString()}
                  </div>

                  {/* Bar */}
                  <div
                    className={`w-full max-w-[48px] rounded-t-lg transition-all duration-300 ${
                      isCurrent
                        ? 'bg-gradient-to-t from-[#2563eb] to-[#38bdf8] shadow-lg shadow-blue-500/20'
                        : 'bg-[#1e3e8f]/60 hover:bg-[#2563eb]'
                    }`}
                    style={{ height: `${item.heightPercent}%` }}
                  />

                  {/* Month label */}
                  <span
                    className={`text-[12px] mt-2 font-medium ${
                      isCurrent
                        ? 'text-[#38bdf8] font-bold'
                        : 'text-[#93c5fd]/70'
                    }`}
                  >
                    {item.month}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Breakdown Area (1 col) */}
        <div className="bg-[#0b193d] rounded-2xl p-6 shadow-xl border border-[#1e429f]/50 flex flex-col justify-between">
          <div>
            <h3 className="text-[18px] font-bold text-[#f0f9ff] mb-5">
              รายรับ vs รายจ่าย
            </h3>

            <div className="space-y-4">
              {/* Income */}
              <div>
                <div className="flex justify-between text-[13px] mb-1 font-medium">
                  <span className="text-[#93c5fd]">รายรับ (฿15,000)</span>
                  <span className="text-[#38bdf8] font-bold">100%</span>
                </div>
                <div className="w-full bg-[#070e24] rounded-full h-2.5 overflow-hidden border border-[#1e429f]/40">
                  <div className="bg-[#38bdf8] h-full rounded-full w-full" />
                </div>
              </div>

              {/* Needs */}
              <div>
                <div className="flex justify-between text-[13px] mb-1 font-medium">
                  <span className="text-[#93c5fd]">รายจ่ายจำเป็น (฿6,000)</span>
                  <span className="text-[#60a5fa] font-bold">40%</span>
                </div>
                <div className="w-full bg-[#070e24] rounded-full h-2.5 overflow-hidden border border-[#1e429f]/40">
                  <div className="bg-[#2563eb] h-full rounded-full w-[40%]" />
                </div>
              </div>

              {/* Wants */}
              <div>
                <div className="flex justify-between text-[13px] mb-1 font-medium">
                  <span className="text-[#93c5fd]">รายจ่ายฟุ่มเฟือย (฿3,000)</span>
                  <span className="text-[#f43f5e] font-bold">20%</span>
                </div>
                <div className="w-full bg-[#070e24] rounded-full h-2.5 overflow-hidden border border-[#1e429f]/40">
                  <div className="bg-[#f43f5e] h-full rounded-full w-[20%]" />
                </div>
              </div>

              {/* Savings */}
              <div>
                <div className="flex justify-between text-[13px] mb-1 font-medium">
                  <span className="text-[#93c5fd]">เงินออม (฿6,000)</span>
                  <span className="text-[#67e8f9] font-bold">40%</span>
                </div>
                <div className="w-full bg-[#070e24] rounded-full h-2.5 overflow-hidden border border-[#1e429f]/40">
                  <div className="bg-[#67e8f9] h-full rounded-full w-[40%]" />
                </div>
              </div>
            </div>
          </div>

          <div className="mt-6 p-3.5 bg-[#070e24] rounded-xl border border-[#1e429f]/50">
            <p className="text-[13px] text-[#7dd3fc] leading-relaxed flex items-start gap-1.5 font-medium">
              <span className="material-symbols-outlined text-[18px] text-[#38bdf8] shrink-0 mt-0.5">lightbulb</span>
              <span>คุณออมได้ 40% ของรายได้ ถือว่าอยู่ในเกณฑ์ดีมาก! ชนะค่าเฉลี่ยวัยเรียน</span>
            </p>
          </div>
        </div>
      </div>

      {/* Bottom Bento Row: Goals and Achievements */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Goals Progress */}
        <div className="bg-[#0b193d] rounded-2xl p-6 shadow-xl border border-[#1e429f]/50">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-[18px] font-bold text-[#f0f9ff]">
              เป้าหมายของคุณ
            </h3>
            <button
              onClick={() => onNavigate('goals')}
              className="text-[13px] font-semibold text-[#38bdf8] hover:text-[#7dd3fc] hover:underline cursor-pointer"
            >
              จัดการเป้าหมาย
            </button>
          </div>

          <div className="space-y-5">
            {goals.slice(0, 3).map((goal) => {
              const percent = goal.targetAmount > 0 ? Math.min(Math.round((goal.currentAmount / goal.targetAmount) * 100), 100) : 0;
              return (
                <div key={goal.id}>
                  <div className="flex justify-between items-center mb-2">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 rounded-xl bg-[#1e429f]/40 border border-[#3b82f6]/40 text-[#38bdf8] flex items-center justify-center">
                        <span className="material-symbols-outlined text-[20px]">{goal.icon || 'flag'}</span>
                      </div>
                      <div>
                        <h4 className="text-[14px] font-bold text-[#f0f9ff]">
                          {goal.name}
                        </h4>
                        <p className="text-[12px] text-[#93c5fd]">
                          ฿{goal.currentAmount.toLocaleString()} / ฿{goal.targetAmount.toLocaleString()}
                        </p>
                      </div>
                    </div>
                    <span className="text-[14px] font-bold text-[#38bdf8]">
                      {percent}%
                    </span>
                  </div>
                  <div className="w-full bg-[#070e24] rounded-full h-2 overflow-hidden border border-[#1e429f]/40">
                    <div className="bg-gradient-to-r from-[#2563eb] to-[#38bdf8] h-full rounded-full" style={{ width: `${percent}%` }} />
                  </div>
                </div>
              );
            })}
          </div>

          <button
            onClick={() => onNavigate('goals')}
            className="mt-6 w-full py-2.5 border border-dashed border-[#38bdf8]/50 rounded-xl text-[#38bdf8] hover:bg-[#132a63] transition-colors text-[14px] font-bold cursor-pointer"
          >
            + เพิ่มเป้าหมายใหม่
          </button>
        </div>

        {/* Gamification Badges */}
        <div className="bg-[#0b193d] rounded-2xl p-6 shadow-xl border border-[#1e429f]/50 flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-[18px] font-bold text-[#f0f9ff]">
                ความสำเร็จของคุณ
              </h3>
              <button
                onClick={() => onNavigate('profile')}
                className="text-[13px] font-semibold text-[#38bdf8] hover:text-[#7dd3fc] hover:underline cursor-pointer"
              >
                ดูทั้งหมด
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
              {/* Badge 1 */}
              <div className="flex flex-col items-center p-3 rounded-xl bg-[#070e24] border border-[#1e429f]/40 hover:border-[#38bdf8]/50 transition-colors">
                <div className="w-14 h-14 rounded-full bg-[#1e429f]/50 text-[#38bdf8] flex items-center justify-center mb-2 border-2 border-[#38bdf8]">
                  <span className="material-symbols-outlined text-[28px]">star</span>
                </div>
                <p className="text-[12px] font-bold text-[#e0f2fe]">นักออมมือใหม่</p>
                <span className="text-[10px] text-[#67e8f9] font-semibold">ปลดล็อกแล้ว</span>
              </div>

              {/* Badge 2 */}
              <div className="flex flex-col items-center p-3 rounded-xl bg-[#070e24] border border-[#1e429f]/40 hover:border-[#38bdf8]/50 transition-colors">
                <div className="w-14 h-14 rounded-full bg-[#1e429f]/50 text-[#38bdf8] flex items-center justify-center mb-2 border-2 border-[#60a5fa]">
                  <span className="material-symbols-outlined text-[28px]">local_fire_department</span>
                </div>
                <p className="text-[12px] font-bold text-[#e0f2fe]">ออมต่อเนื่อง 7 วัน</p>
                <span className="text-[10px] text-[#67e8f9] font-semibold">ปลดล็อกแล้ว</span>
              </div>

              {/* Badge 3 (Locked) */}
              <div className="flex flex-col items-center p-3 rounded-xl bg-[#070e24]/60 border border-[#1e429f]/20 opacity-50 grayscale">
                <div className="w-14 h-14 rounded-full bg-[#0b193d] flex items-center justify-center mb-2 border border-slate-700">
                  <span className="material-symbols-outlined text-[28px] text-gray-500">diamond</span>
                </div>
                <p className="text-[12px] font-semibold text-gray-400">นักออมตัวจริง</p>
                <span className="text-[10px] text-gray-500">ล็อกอยู่</span>
              </div>

              {/* Badge 4 (Locked) */}
              <div className="flex flex-col items-center p-3 rounded-xl bg-[#070e24]/60 border border-[#1e429f]/20 opacity-50 grayscale">
                <div className="w-14 h-14 rounded-full bg-[#0b193d] flex items-center justify-center mb-2 border border-slate-700">
                  <span className="material-symbols-outlined text-[28px] text-gray-500">emoji_events</span>
                </div>
                <p className="text-[12px] font-semibold text-gray-400">บรรลุเป้าหมายแรก</p>
                <span className="text-[10px] text-gray-500">ล็อกอยู่</span>
              </div>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-[#1e429f]/40 text-center">
            <button
              onClick={() => onNavigate('quiz')}
              className="text-[13px] font-semibold text-[#38bdf8] hover:text-[#7dd3fc] hover:underline flex items-center justify-center gap-1.5 mx-auto cursor-pointer"
            >
              <span className="material-symbols-outlined text-[16px]">quiz</span>
              ทำแบบทดสอบเพื่อปลดล็อกป้าย "ผู้รอบรู้"
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
