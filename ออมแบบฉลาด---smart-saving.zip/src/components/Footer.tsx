import React from 'react';
import { TabType } from '../types';

interface FooterProps {
  onSelectTab?: (tab: TabType) => void;
}

export const Footer: React.FC<FooterProps> = ({ onSelectTab }) => {
  return (
    <footer className="w-full bg-[#050b1a] border-t border-[#1e429f]/40 py-8 px-4 md:px-8 mt-auto transition-colors">
      <div className="max-w-[1240px] mx-auto flex flex-col md:flex-row justify-between items-center gap-4 text-center md:text-left">
        <div>
          <span className="text-[17px] font-bold text-[#60a5fa] block mb-1">
            ออมแบบฉลาด
          </span>
          <span className="text-[13px] text-[#93c5fd]">
            © 2024 ออมแบบฉลาดด้วยเทคโนโลยี. All rights reserved.
          </span>
        </div>

        <div className="flex flex-wrap justify-center gap-6 text-[13px] text-[#7dd3fc]/80">
          <button
            onClick={() => onSelectTab?.('about')}
            className="hover:text-[#38bdf8] transition-colors hover:underline"
          >
            เกี่ยวกับเรา
          </button>
          <button
            onClick={() => onSelectTab?.('knowledge')}
            className="hover:text-[#38bdf8] transition-colors hover:underline"
          >
            คลังความรู้
          </button>
          <button
            onClick={() => onSelectTab?.('profile')}
            className="hover:text-[#38bdf8] transition-colors hover:underline"
          >
            นโยบายความเป็นส่วนตัว
          </button>
          <button
            onClick={() => onSelectTab?.('about')}
            className="hover:text-[#38bdf8] transition-colors hover:underline"
          >
            ติดต่อเรา
          </button>
        </div>
      </div>
    </footer>
  );
};
