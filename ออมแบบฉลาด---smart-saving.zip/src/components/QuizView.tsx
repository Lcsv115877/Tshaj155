import React, { useState } from 'react';
import { TabType } from '../types';
import { QUIZ_QUESTIONS } from '../data/initialData';

interface QuizViewProps {
  onNavigate: (tab: TabType) => void;
  onCompleteQuiz?: (score: number) => void;
}

export const QuizView: React.FC<QuizViewProps> = ({ onNavigate, onCompleteQuiz }) => {
  const [currentQIndex, setCurrentQIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [userAnswers, setUserAnswers] = useState<number[]>([]);
  const [isFinished, setIsFinished] = useState(false);
  const [showReviewModal, setShowReviewModal] = useState(false);

  const currentQ = QUIZ_QUESTIONS[currentQIndex];
  const progressPercent = ((currentQIndex + 1) / QUIZ_QUESTIONS.length) * 100;

  const handleSelectOption = (idx: number) => {
    setSelectedOption(idx);
  };

  const handleSubmitAnswer = () => {
    if (selectedOption === null) return;

    const newAnswers = [...userAnswers, selectedOption];
    setUserAnswers(newAnswers);

    if (currentQIndex + 1 < QUIZ_QUESTIONS.length) {
      setCurrentQIndex(currentQIndex + 1);
      setSelectedOption(null);
    } else {
      // Finished
      setIsFinished(true);
      const calculatedScore = newAnswers.reduce((acc, ans, i) => {
        return ans === QUIZ_QUESTIONS[i].correctAnswer ? acc + 1 : acc;
      }, 0);
      onCompleteQuiz?.(calculatedScore);
    }
  };

  const handleRetry = () => {
    setCurrentQIndex(0);
    setSelectedOption(null);
    setUserAnswers([]);
    setIsFinished(false);
    setShowReviewModal(false);
  };

  const finalScore = userAnswers.reduce((acc, ans, i) => {
    return ans === QUIZ_QUESTIONS[i]?.correctAnswer ? acc + 1 : acc;
  }, 0);

  const getFeedbackMessage = (score: number) => {
    if (score === 5) return 'ยอดเยี่ยมมาก! คุณเป็นผู้เชี่ยวชาญด้านการออมระดับเซียน 🎉';
    if (score >= 3) return 'เยี่ยมมาก! คุณมีพื้นฐานการออมและการเงินที่ดีเยี่ยม 👏';
    return 'ไม่เป็นไรนะ! ลองศึกษาเพิ่มเติมในคลังความรู้แล้วมาลองทดสอบใหม่อีกครั้ง 💪';
  };

  return (
    <div className="flex-grow pt-24 pb-16 px-4 md:px-8 max-w-3xl mx-auto w-full">
      {/* Header */}
      <div className="mb-8 text-center">
        <h1 className="text-[30px] sm:text-[36px] font-bold text-[#f0f9ff] mb-2 tracking-tight">
          ทดสอบความรู้การออม
        </h1>
        <p className="text-[16px] text-[#93c5fd]">
          มาดูกันว่าคุณมีความรู้เรื่องการจัดการเงินมากแค่ไหน!
        </p>
      </div>

      {!isFinished ? (
        /* Quiz Container */
        <div
          id="quiz-container"
          className="bg-[#0b193d] rounded-2xl shadow-xl border border-[#1e429f]/50 p-6 md:p-8"
        >
          {/* Progress bar */}
          <div className="mb-6">
            <div className="flex justify-between items-center mb-2">
              <span className="text-[12px] font-bold text-[#93c5fd] uppercase tracking-wider">
                คำถามที่ {currentQIndex + 1}/{QUIZ_QUESTIONS.length}
              </span>
              <span className="text-[12px] font-bold text-[#38bdf8]">
                {Math.round(progressPercent)}%
              </span>
            </div>
            <div className="w-full bg-[#070e24] rounded-full h-2 overflow-hidden border border-[#1e429f]/40">
              <div
                className="bg-gradient-to-r from-[#2563eb] to-[#38bdf8] h-2 rounded-full transition-all duration-300"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>

          {/* Question */}
          <div className="mb-6">
            <h3 className="text-[19px] sm:text-[22px] font-bold text-[#f0f9ff] mb-6 leading-snug">
              {currentQ.question}
            </h3>

            {/* Options list */}
            <div className="flex flex-col gap-3">
              {currentQ.options.map((opt, idx) => {
                const isSelected = selectedOption === idx;
                return (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleSelectOption(idx)}
                    className={`w-full text-left p-4 rounded-xl border-2 text-[15px] sm:text-[16px] font-medium transition-all cursor-pointer ${
                      isSelected
                        ? 'border-[#38bdf8] bg-[#1e429f]/60 text-[#f0f9ff] font-bold shadow-md'
                        : 'border-[#1e429f]/40 bg-[#070e24] text-[#93c5fd] hover:bg-[#132a63] hover:text-[#f0f9ff]'
                    }`}
                  >
                    {opt}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Action button */}
          <div className="mt-8 flex justify-end">
            <button
              id="submit-quiz-btn"
              type="button"
              disabled={selectedOption === null}
              onClick={handleSubmitAnswer}
              className="bg-[#2563eb] hover:bg-[#1d4ed8] disabled:opacity-50 disabled:cursor-not-allowed text-white px-7 py-3 rounded-xl font-bold text-[15px] shadow-md transition-all active:scale-98 cursor-pointer border border-[#60a5fa]/40"
            >
              {currentQIndex + 1 === QUIZ_QUESTIONS.length ? 'ดูผลคะแนน' : 'ส่งคำตอบ'}
            </button>
          </div>
        </div>
      ) : (
        /* Results Container */
        <div
          id="results-container"
          className="bg-[#0b193d] rounded-2xl shadow-xl border border-[#1e429f]/50 p-8 md:p-10 text-center animate-in fade-in zoom-in-95 duration-200"
        >
          <div className="mb-5 flex justify-center">
            <div className="w-20 h-20 rounded-full bg-[#1e429f]/50 border-2 border-[#38bdf8] text-[#38bdf8] flex items-center justify-center shadow-lg">
              <span className="material-symbols-outlined text-[48px]">emoji_events</span>
            </div>
          </div>

          <h2 className="text-[28px] font-extrabold text-[#f0f9ff] mb-1">
            สรุปคะแนนของคุณ
          </h2>

          <p className="text-[24px] font-bold text-[#38bdf8] mb-4">
            คุณได้ <span className="text-[32px] text-[#f0f9ff]">{finalScore}</span> / {QUIZ_QUESTIONS.length} คะแนน
          </p>

          <p className="text-[16px] text-[#93c5fd] max-w-md mx-auto mb-8 leading-relaxed">
            {getFeedbackMessage(finalScore)}
          </p>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row justify-center gap-3">
            <button
              id="retry-quiz-btn"
              onClick={handleRetry}
              className="bg-[#2563eb] hover:bg-[#1d4ed8] text-white px-6 py-3 rounded-xl font-bold text-[15px] shadow-md transition-all cursor-pointer active:scale-98 flex items-center justify-center gap-1.5 border border-[#60a5fa]/40"
            >
              <span className="material-symbols-outlined text-[18px]">replay</span>
              ทำแบบทดสอบอีกครั้ง
            </button>

            <button
              id="review-quiz-btn"
              onClick={() => setShowReviewModal(true)}
              className="bg-[#070e24] hover:bg-[#132a63] border border-[#1e429f] text-[#38bdf8] px-6 py-3 rounded-xl font-bold text-[15px] transition-all cursor-pointer active:scale-98 flex items-center justify-center gap-1.5"
            >
              <span className="material-symbols-outlined text-[18px]">fact_check</span>
              ดูเฉลยและคำอธิบาย
            </button>

            <button
              onClick={() => onNavigate('home')}
              className="border border-[#1e429f] hover:bg-[#132a63] text-[#93c5fd] px-6 py-3 rounded-xl font-bold text-[15px] transition-all cursor-pointer"
            >
              กลับหน้าแรก
            </button>
          </div>
        </div>
      )}

      {/* Answer Review Modal */}
      {showReviewModal && (
        <div
          className="fixed inset-0 z-[100] bg-black/70 backdrop-blur-xs flex items-center justify-center p-4"
          onClick={() => setShowReviewModal(false)}
        >
          <div
            className="bg-[#0b193d] border border-[#1e429f] w-full max-w-2xl max-h-[85vh] rounded-2xl shadow-2xl overflow-hidden flex flex-col animate-in fade-in zoom-in-95 duration-200"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-between items-center p-5 border-b border-[#1e429f]/50">
              <h3 className="text-[18px] font-bold text-[#f0f9ff] flex items-center gap-2">
                <span className="material-symbols-outlined text-[#38bdf8]">fact_check</span>
                เฉลยและคำอธิบายแบบละเอียด
              </h3>
              <button
                onClick={() => setShowReviewModal(false)}
                className="text-[#93c5fd] hover:text-white p-1 rounded-full cursor-pointer"
              >
                <span className="material-symbols-outlined text-[20px]">close</span>
              </button>
            </div>

            <div className="p-6 overflow-y-auto space-y-6">
              {QUIZ_QUESTIONS.map((q, idx) => {
                const userChoice = userAnswers[idx];
                const isCorrect = userChoice === q.correctAnswer;

                return (
                  <div
                    key={q.id}
                    className={`p-4 rounded-xl border ${
                      isCorrect
                        ? 'border-[#38bdf8]/40 bg-[#070e24]'
                        : 'border-red-900/50 bg-[#1c0e14]'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <h4 className="font-bold text-[15px] text-[#f0f9ff]">
                        {q.question}
                      </h4>
                      <span
                        className={`shrink-0 px-2 py-0.5 rounded text-[11px] font-bold ${
                          isCorrect
                            ? 'bg-[#1e429f] text-[#38bdf8] border border-[#38bdf8]/40'
                            : 'bg-red-950 text-red-300 border border-red-500/40'
                        }`}
                      >
                        {isCorrect ? 'ถูกต้อง (+1)' : 'ตอบผิด'}
                      </span>
                    </div>

                    <div className="space-y-1 text-[13px] mb-2">
                      <p className="text-[#93c5fd]">
                        คำตอบของคุณ:{' '}
                        <strong className={isCorrect ? 'text-[#38bdf8]' : 'text-red-400'}>
                          {userChoice !== undefined ? q.options[userChoice] : 'ไม่ได้ตอบ'}
                        </strong>
                      </p>
                      {!isCorrect && (
                        <p className="text-[#38bdf8] font-semibold">
                          คำตอบที่ถูกต้อง: {q.options[q.correctAnswer]}
                        </p>
                      )}
                    </div>

                    <div className="text-[12px] bg-[#0b193d] p-2.5 rounded-lg text-[#93c5fd] border border-[#1e429f]/40">
                      <strong className="text-[#f0f9ff]">💡 คำอธิบาย:</strong> {q.explanation}
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="p-4 border-t border-[#1e429f]/50 flex justify-end">
              <button
                onClick={() => setShowReviewModal(false)}
                className="bg-[#2563eb] hover:bg-[#1d4ed8] text-white px-5 py-2 rounded-xl text-[14px] font-bold cursor-pointer"
              >
                ปิด
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
