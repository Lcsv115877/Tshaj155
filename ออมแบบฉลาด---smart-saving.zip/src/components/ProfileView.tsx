import React, { useState } from 'react';
import { UserProfile, AchievementBadge, TabType } from '../types';

interface ProfileViewProps {
  profile: UserProfile;
  badges: AchievementBadge[];
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
  onUpdateProfile: (updated: Partial<UserProfile>) => void;
  onResetData: () => void;
  onNavigate: (tab: TabType) => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  profile,
  badges,
  isDarkMode,
  onToggleDarkMode,
  onUpdateProfile,
  onResetData,
  onNavigate,
}) => {
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editName, setEditName] = useState(profile.name);
  const [editRole, setEditRole] = useState(profile.role);
  const [editTarget, setEditTarget] = useState(profile.targetSaved);
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateProfile({
      name: editName.trim() || profile.name,
      role: editRole.trim() || profile.role,
      targetSaved: Number(editTarget) || profile.targetSaved,
    });
    setIsEditModalOpen(false);
  };

  const progressPercent = profile.targetSaved > 0
    ? Math.min(Math.round((profile.totalSaved / profile.targetSaved) * 100), 100)
    : 75;

  return (
    <div className="flex-grow pt-24 pb-16 px-4 md:px-8 max-w-[1240px] mx-auto w-full">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: User Card & Actions (4 cols) */}
        <div className="lg:col-span-4 flex flex-col gap-6">
          {/* Profile Card */}
          <div className="bg-[#0b193d] rounded-2xl shadow-xl p-6 md:p-8 flex flex-col items-center text-center border border-[#1e429f]/50">
            <div className="relative w-32 h-32 mb-4">
              <img
                src={profile.avatarUrl}
                alt={profile.name}
                referrerPolicy="no-referrer"
                className="rounded-full w-full h-full object-cover border-4 border-[#1e429f] shadow-sm"
              />
              <button
                onClick={() => setIsEditModalOpen(true)}
                className="absolute bottom-0 right-0 bg-[#2563eb] hover:bg-[#1d4ed8] text-white rounded-full p-2 shadow-md hover:scale-105 transition-transform cursor-pointer border border-[#60a5fa]/50"
                title="แก้ไขรูปภาพและข้อมูล"
              >
                <span className="material-symbols-outlined text-[16px]">edit</span>
              </button>
            </div>

            <h1 className="text-[22px] font-bold text-[#f0f9ff] mb-1">
              {profile.name}
            </h1>
            <p className="text-[14px] text-[#93c5fd] mb-6">
              {profile.role}
            </p>

            {/* Level and Progress bar */}
            <div className="w-full flex justify-between px-6 py-3.5 bg-[#070e24] rounded-xl mb-6 border border-[#1e429f]/50">
              <div className="flex flex-col items-center">
                <span className="text-[11px] font-bold text-[#93c5fd]/70 uppercase tracking-wider">
                  เลเวล
                </span>
                <span className="text-[22px] font-extrabold text-[#38bdf8]">
                  {profile.level}
                </span>
              </div>
              <div className="w-px bg-[#1e429f]/60" />
              <div className="flex flex-col items-center">
                <span className="text-[11px] font-bold text-[#93c5fd]/70 uppercase tracking-wider">
                  ความคืบหน้า
                </span>
                <span className="text-[22px] font-extrabold text-[#67e8f9]">
                  {progressPercent}%
                </span>
              </div>
            </div>

            <button
              id="edit-profile-btn"
              onClick={() => setIsEditModalOpen(true)}
              className="w-full bg-[#2563eb] hover:bg-[#1d4ed8] text-white font-bold text-[15px] py-3 rounded-xl shadow-md transition-all active:scale-98 cursor-pointer border border-[#60a5fa]/40"
            >
              แก้ไขโปรไฟล์
            </button>
          </div>

          {/* Action Links */}
          <div className="bg-[#0b193d] rounded-2xl shadow-xl p-3 border border-[#1e429f]/50">
            <button
              onClick={() => onNavigate('calculator')}
              className="w-full flex items-center justify-between p-3 hover:bg-[#132a63] rounded-xl transition-colors group cursor-pointer"
            >
              <div className="flex items-center gap-3 text-[#f0f9ff]">
                <span className="material-symbols-outlined text-[#38bdf8]">
                  settings
                </span>
                <span className="text-[14px] font-medium">ตั้งค่าแผนการออม</span>
              </div>
              <span className="material-symbols-outlined text-[#93c5fd]/60 group-hover:translate-x-1 transition-transform text-[20px]">
                chevron_right
              </span>
            </button>

            <div className="h-px bg-[#1e429f]/40 my-1 mx-2" />

            <button
              onClick={onToggleDarkMode}
              className="w-full flex items-center justify-between p-3 hover:bg-[#132a63] rounded-xl transition-colors group cursor-pointer"
            >
              <div className="flex items-center gap-3 text-[#f0f9ff]">
                <span className="material-symbols-outlined text-[#38bdf8]">
                  {isDarkMode ? 'light_mode' : 'dark_mode'}
                </span>
                <span className="text-[14px] font-medium">
                  {isDarkMode ? 'โหมดน้ำเงินฟ้า (หลัก)' : 'โหมดน้ำเงินเข้ม'}
                </span>
              </div>
              <div
                className={`w-11 h-6 rounded-full transition-colors relative p-1 ${
                  isDarkMode ? 'bg-[#2563eb]' : 'bg-[#1e3e8f]'
                }`}
              >
                <div
                  className={`w-4 h-4 rounded-full bg-[#38bdf8] transition-transform ${
                    isDarkMode ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </div>
            </button>

            <div className="h-px bg-[#1e429f]/40 my-1 mx-2" />

            <button
              onClick={() => setShowResetConfirm(true)}
              className="w-full flex items-center justify-between p-3 hover:bg-[#450a0a]/40 text-[#f87171] rounded-xl transition-colors group cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <span className="material-symbols-outlined text-[#f87171]">restart_alt</span>
                <span className="text-[14px] font-semibold">รีเซ็ตข้อมูลทั้งหมด</span>
              </div>
            </button>
          </div>
        </div>

        {/* Right Column: Stats & Bento Grid (8 cols) */}
        <div className="lg:col-span-8 flex flex-col gap-6">
          {/* Financial Summary Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Total Savings Card */}
            <div className="bg-[#0b193d] rounded-2xl shadow-xl p-6 border border-[#1e429f]/50 flex flex-col justify-between hover:-translate-y-0.5 transition-transform">
              <div className="flex justify-between items-start mb-4">
                <div className="flex items-center gap-2.5">
                  <div className="p-2.5 bg-[#1e429f]/40 border border-[#3b82f6]/40 text-[#38bdf8] rounded-xl">
                    <span className="material-symbols-outlined text-[22px]">savings</span>
                  </div>
                  <span className="text-[14px] font-medium text-[#93c5fd]">
                    ยอดเงินออมรวม
                  </span>
                </div>
                <span className="text-[11px] font-bold bg-[#1e429f]/50 border border-[#38bdf8]/40 text-[#38bdf8] px-2.5 py-1 rounded-md">
                  +12% เดือนนี้
                </span>
              </div>

              <div>
                <h2 className="text-[28px] font-bold text-[#f0f9ff]">
                  ฿{profile.totalSaved.toLocaleString()}
                </h2>
                <p className="text-[13px] text-[#93c5fd] mt-1">
                  จากเป้าหมาย ฿{profile.targetSaved.toLocaleString()}
                </p>
              </div>

              <div className="w-full bg-[#070e24] h-2.5 rounded-full mt-4 overflow-hidden border border-[#1e429f]/40">
                <div
                  className="bg-gradient-to-r from-[#2563eb] to-[#38bdf8] h-full rounded-full transition-all duration-500"
                  style={{ width: `${progressPercent}%` }}
                />
              </div>
            </div>

            {/* Average Monthly Card */}
            <div className="bg-[#0b193d] rounded-2xl shadow-xl p-6 border border-[#1e429f]/50 flex flex-col justify-between hover:-translate-y-0.5 transition-transform">
              <div className="flex justify-between items-start mb-4">
                <div className="flex items-center gap-2.5">
                  <div className="p-2.5 bg-[#1e429f]/40 border border-[#3b82f6]/40 text-[#67e8f9] rounded-xl">
                    <span className="material-symbols-outlined text-[22px]">monitoring</span>
                  </div>
                  <span className="text-[14px] font-medium text-[#93c5fd]">
                    ออมเฉลี่ยต่อเดือน
                  </span>
                </div>
              </div>

              <div>
                <h2 className="text-[28px] font-bold text-[#f0f9ff]">
                  ฿{profile.monthlyAverage.toLocaleString()}
                </h2>
                <p className="text-[13px] text-[#93c5fd] mt-1">
                  คงที่มา 3 เดือน
                </p>
              </div>

              <div className="mt-4 pt-2 border-t border-[#1e429f]/40 text-[12px] text-[#67e8f9] font-semibold flex items-center gap-1">
                <span className="material-symbols-outlined text-[16px]">verified</span>
                วินัยการเงินอยู่ในระดับดีเยี่ยม
              </div>
            </div>
          </div>

          {/* Learning Progress (Quizzes) */}
          <div className="bg-[#0b193d] rounded-2xl shadow-xl p-6 border border-[#1e429f]/50">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-[18px] font-bold text-[#f0f9ff]">
                ความรู้ &amp; แบบทดสอบ
              </h3>
              <button
                onClick={() => onNavigate('quiz')}
                className="text-[13px] font-semibold text-[#38bdf8] hover:text-[#7dd3fc] hover:underline cursor-pointer"
              >
                ทำแบบทดสอบเพิ่ม
              </button>
            </div>

            <div className="space-y-3">
              {profile.completedQuizzes.map((quiz, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-3.5 bg-[#070e24] border border-[#1e429f]/40 rounded-xl"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-[#1e429f]/40 border border-[#3b82f6]/40 text-[#38bdf8] rounded-full flex items-center justify-center">
                      <span className="material-symbols-outlined text-[20px]">{quiz.icon}</span>
                    </div>
                    <div>
                      <h4 className="text-[14px] font-bold text-[#f0f9ff]">
                        {quiz.title}
                      </h4>
                      <p className="text-[12px] text-[#93c5fd]">
                        คะแนน: {quiz.score}/{quiz.total}
                      </p>
                    </div>
                  </div>
                  <span className="material-symbols-outlined text-[#67e8f9] text-[22px]">
                    check_circle
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Badges / Achievements */}
          <div className="bg-[#0b193d] rounded-2xl shadow-xl p-6 border border-[#1e429f]/50">
            <h3 className="text-[18px] font-bold text-[#f0f9ff] mb-4">
              ป้ายแห่งความสำเร็จ
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
              {badges.map((badge) => (
                <div
                  key={badge.id}
                  className={`flex flex-col items-center p-3.5 rounded-xl transition-all border ${
                    badge.unlocked
                      ? 'bg-[#070e24] border-[#1e429f]/60 shadow-md'
                      : 'bg-[#070e24]/50 border-[#1e429f]/20 opacity-50 grayscale'
                  }`}
                  title={badge.description}
                >
                  <img
                    src={badge.imageUrl}
                    alt={badge.title}
                    referrerPolicy="no-referrer"
                    className="w-16 h-16 object-contain mb-2 hover:scale-105 transition-transform"
                  />
                  <span className="text-[13px] font-bold text-[#f0f9ff]">
                    {badge.title}
                  </span>
                  <span className={`text-[10px] mt-0.5 font-medium ${badge.unlocked ? 'text-[#67e8f9]' : 'text-gray-400'}`}>
                    {badge.unlocked ? 'ปลดล็อกแล้ว' : 'ยังไม่ปลดล็อก'}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Edit Profile Modal */}
      {isEditModalOpen && (
        <div
          className="fixed inset-0 z-[100] bg-black/70 backdrop-blur-xs flex items-center justify-center p-4"
          onClick={() => setIsEditModalOpen(false)}
        >
          <div
            className="bg-[#0b193d] border border-[#1e429f] w-full max-w-md rounded-2xl shadow-2xl p-6 animate-in fade-in zoom-in-95 duration-200"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-between items-center mb-5">
              <h3 className="text-[18px] font-bold text-[#f0f9ff]">
                แก้ไขข้อมูลโปรไฟล์
              </h3>
              <button
                onClick={() => setIsEditModalOpen(false)}
                className="text-[#93c5fd] hover:text-white p-1 cursor-pointer"
              >
                <span className="material-symbols-outlined text-[20px]">close</span>
              </button>
            </div>

            <form onSubmit={handleSaveProfile} className="space-y-4">
              <div>
                <label className="block text-[13px] font-semibold text-[#93c5fd] mb-1.5">
                  ชื่อ - นามสกุล
                </label>
                <input
                  type="text"
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-[#1e429f] bg-[#070e24] text-[#f0f9ff] outline-none focus:border-[#38bdf8] text-[14px]"
                  required
                />
              </div>

              <div>
                <label className="block text-[13px] font-semibold text-[#93c5fd] mb-1.5">
                  สถานะ / อาชีพ
                </label>
                <input
                  type="text"
                  value={editRole}
                  onChange={(e) => setEditRole(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-[#1e429f] bg-[#070e24] text-[#f0f9ff] outline-none focus:border-[#38bdf8] text-[14px]"
                />
              </div>

              <div>
                <label className="block text-[13px] font-semibold text-[#93c5fd] mb-1.5">
                  เป้าหมายเงินออมรวม (บาท)
                </label>
                <input
                  type="number"
                  value={editTarget}
                  onChange={(e) => setEditTarget(Number(e.target.value))}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-[#1e429f] bg-[#070e24] text-[#f0f9ff] outline-none focus:border-[#38bdf8] text-[14px]"
                />
              </div>

              <div className="flex justify-end gap-2.5 pt-3">
                <button
                  type="button"
                  onClick={() => setIsEditModalOpen(false)}
                  className="px-4 py-2 text-[14px] font-semibold text-[#93c5fd] hover:bg-[#132a63] rounded-xl cursor-pointer"
                >
                  ยกเลิก
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#2563eb] hover:bg-[#1d4ed8] text-white text-[14px] font-bold rounded-xl shadow-md cursor-pointer border border-[#60a5fa]/40"
                >
                  บันทึกข้อมูล
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Reset Confirmation Dialog */}
      {showResetConfirm && (
        <div
          className="fixed inset-0 z-[100] bg-black/70 backdrop-blur-xs flex items-center justify-center p-4"
          onClick={() => setShowResetConfirm(false)}
        >
          <div
            className="bg-[#0b193d] border border-[#1e429f] w-full max-w-sm rounded-2xl shadow-2xl p-6 text-center animate-in fade-in zoom-in-95 duration-200"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-12 h-12 rounded-full bg-red-950/60 border border-red-500/40 text-red-400 flex items-center justify-center mx-auto mb-3">
              <span className="material-symbols-outlined text-[28px]">warning</span>
            </div>
            <h3 className="text-[18px] font-bold text-[#f0f9ff] mb-2">
              ยืนยันการรีเซ็ตข้อมูล?
            </h3>
            <p className="text-[13px] text-[#93c5fd] mb-6">
              การกระทำนี้จะคืนค่าเป้าหมายและการตั้งค่าทั้งหมดกลับสู่ค่าเริ่มต้น
            </p>
            <div className="flex justify-center gap-3">
              <button
                onClick={() => setShowResetConfirm(false)}
                className="px-4 py-2 text-[13px] font-semibold text-[#93c5fd] hover:bg-[#132a63] rounded-xl cursor-pointer"
              >
                ยกเลิก
              </button>
              <button
                onClick={() => {
                  onResetData();
                  setShowResetConfirm(false);
                }}
                className="px-5 py-2 bg-red-600 hover:bg-red-700 text-white text-[13px] font-bold rounded-xl shadow-md cursor-pointer"
              >
                รีเซ็ตข้อมูล
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
