import React, { useState, useEffect } from 'react';
import { TabType, SavingsGoal, UserProfile, AchievementBadge } from './types';
import { INITIAL_GOALS, INITIAL_PROFILE, INITIAL_BADGES } from './data/initialData';
import { TopNav } from './components/TopNav';
import { Footer } from './components/Footer';
import { HomeView } from './components/HomeView';
import { AboutSavingView } from './components/AboutSavingView';
import { CalculatorView } from './components/CalculatorView';
import { GoalsView } from './components/GoalsView';
import { DashboardView } from './components/DashboardView';
import { KnowledgeView } from './components/KnowledgeView';
import { QuizView } from './components/QuizView';
import { ProfileView } from './components/ProfileView';

export default function App() {
  const [currentTab, setCurrentTab] = useState<TabType>('home');
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    return localStorage.getItem('smart_saving_theme') === 'dark';
  });

  const [goals, setGoals] = useState<SavingsGoal[]>(() => {
    const saved = localStorage.getItem('smart_saving_goals');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return INITIAL_GOALS;
  });

  const [profile, setProfile] = useState<UserProfile>(() => {
    const saved = localStorage.getItem('smart_saving_profile');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return INITIAL_PROFILE;
  });

  const [badges, setBadges] = useState<AchievementBadge[]>(() => {
    const saved = localStorage.getItem('smart_saving_badges');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return INITIAL_BADGES;
  });

  // Dark mode class sync on documentElement
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('smart_saving_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('smart_saving_theme', 'light');
    }
  }, [isDarkMode]);

  // Persist goals
  useEffect(() => {
    localStorage.setItem('smart_saving_goals', JSON.stringify(goals));
  }, [goals]);

  // Persist profile
  useEffect(() => {
    localStorage.setItem('smart_saving_profile', JSON.stringify(profile));
  }, [profile]);

  // Persist badges
  useEffect(() => {
    localStorage.setItem('smart_saving_badges', JSON.stringify(badges));
  }, [badges]);

  // Scroll to top on tab change
  const handleSelectTab = (tab: TabType) => {
    setCurrentTab(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleToggleDarkMode = () => {
    setIsDarkMode((prev) => !prev);
  };

  // Add goal handler
  const handleAddGoal = (newGoal: Omit<SavingsGoal, 'id' | 'createdAt'>) => {
    const goal: SavingsGoal = {
      ...newGoal,
      id: `goal-${Date.now()}`,
      createdAt: new Date().toISOString().split('T')[0],
    };
    setGoals((prev) => [goal, ...prev]);

    // Unlock badge 1 if locked
    setBadges((prev) =>
      prev.map((b) => (b.id === 'badge-1' ? { ...b, unlocked: true } : b))
    );
  };

  // Deposit money handler
  const handleDepositMoney = (goalId: string, amount: number) => {
    let reachedTarget = false;

    setGoals((prev) =>
      prev.map((g) => {
        if (g.id === goalId) {
          const nextAmount = g.currentAmount + amount;
          if (nextAmount >= g.targetAmount) {
            reachedTarget = true;
          }
          return { ...g, currentAmount: nextAmount };
        }
        return g;
      })
    );

    // Update profile total saved
    setProfile((prev) => ({
      ...prev,
      totalSaved: prev.totalSaved + amount,
    }));

    // Unlock badge 3 if reached target
    if (reachedTarget) {
      setBadges((prev) =>
        prev.map((b) => (b.id === 'badge-3' ? { ...b, unlocked: true } : b))
      );
    }
  };

  // Delete goal handler
  const handleDeleteGoal = (goalId: string) => {
    setGoals((prev) => prev.filter((g) => g.id !== goalId));
  };

  // Quiz completion handler
  const handleCompleteQuiz = (score: number) => {
    setProfile((prev) => ({
      ...prev,
      level: prev.level + (score >= 4 ? 1 : 0),
      progressPercent: Math.min(prev.progressPercent + 10, 100),
      completedQuizzes: [
        {
          title: 'แบบทดสอบความรู้การออม',
          score,
          total: 5,
          icon: 'quiz',
        },
        ...prev.completedQuizzes.filter((q) => q.title !== 'แบบทดสอบความรู้การออม'),
      ],
    }));

    if (score === 5) {
      setBadges((prev) =>
        prev.map((b) => (b.id === 'badge-4' ? { ...b, unlocked: true } : b))
      );
    }
  };

  // Update profile
  const handleUpdateProfile = (updated: Partial<UserProfile>) => {
    setProfile((prev) => ({ ...prev, ...updated }));
  };

  // Reset all state to defaults
  const handleResetData = () => {
    setGoals(INITIAL_GOALS);
    setProfile(INITIAL_PROFILE);
    setBadges(INITIAL_BADGES);
    localStorage.removeItem('smart_saving_goals');
    localStorage.removeItem('smart_saving_profile');
    localStorage.removeItem('smart_saving_badges');
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#070e24] text-[#e0f2fe] transition-colors duration-200 selection:bg-[#2563eb] selection:text-white">
      {/* Universal Top Navigation */}
      <TopNav
        currentTab={currentTab}
        onSelectTab={handleSelectTab}
        isDarkMode={isDarkMode}
        onToggleDarkMode={handleToggleDarkMode}
      />

      {/* Main Content Area based on Active Tab */}
      <main className="flex-1 flex flex-col">
        {currentTab === 'home' && (
          <HomeView onNavigate={handleSelectTab} />
        )}

        {currentTab === 'about' && (
          <AboutSavingView onNavigate={handleSelectTab} />
        )}

        {currentTab === 'goals' && (
          <GoalsView
            goals={goals}
            onAddGoal={handleAddGoal}
            onDepositMoney={handleDepositMoney}
            onDeleteGoal={handleDeleteGoal}
          />
        )}

        {currentTab === 'calculator' && (
          <CalculatorView onSaveGoal={handleAddGoal} />
        )}

        {currentTab === 'dashboard' && (
          <DashboardView goals={goals} onNavigate={handleSelectTab} />
        )}

        {currentTab === 'knowledge' && (
          <KnowledgeView />
        )}

        {currentTab === 'quiz' && (
          <QuizView onNavigate={handleSelectTab} onCompleteQuiz={handleCompleteQuiz} />
        )}

        {currentTab === 'profile' && (
          <ProfileView
            profile={profile}
            badges={badges}
            isDarkMode={isDarkMode}
            onToggleDarkMode={handleToggleDarkMode}
            onUpdateProfile={handleUpdateProfile}
            onResetData={handleResetData}
            onNavigate={handleSelectTab}
          />
        )}
      </main>

      {/* Mobile Bottom Quick Bar */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#0b1b42]/95 backdrop-blur-md border-t border-[#1e429f]/40 flex justify-around items-center h-16 px-2 shadow-2xl">
        <button
          onClick={() => handleSelectTab('home')}
          className={`flex flex-col items-center justify-center flex-1 py-1 transition-colors ${
            currentTab === 'home'
              ? 'text-[#38bdf8] font-bold'
              : 'text-[#7dd3fc]/60 hover:text-[#93c5fd]'
          }`}
        >
          <span className="material-symbols-outlined text-[22px]">home</span>
          <span className="text-[10px]">หน้าแรก</span>
        </button>

        <button
          onClick={() => handleSelectTab('goals')}
          className={`flex flex-col items-center justify-center flex-1 py-1 transition-colors ${
            currentTab === 'goals'
              ? 'text-[#38bdf8] font-bold'
              : 'text-[#7dd3fc]/60 hover:text-[#93c5fd]'
          }`}
        >
          <span className="material-symbols-outlined text-[22px]">flag</span>
          <span className="text-[10px]">เป้าหมาย</span>
        </button>

        <button
          onClick={() => handleSelectTab('calculator')}
          className={`flex flex-col items-center justify-center flex-1 py-1 transition-colors ${
            currentTab === 'calculator'
              ? 'text-[#38bdf8] font-bold'
              : 'text-[#7dd3fc]/60 hover:text-[#93c5fd]'
          }`}
        >
          <span className="material-symbols-outlined text-[22px]">calculate</span>
          <span className="text-[10px]">คำนวณ</span>
        </button>

        <button
          onClick={() => handleSelectTab('dashboard')}
          className={`flex flex-col items-center justify-center flex-1 py-1 transition-colors ${
            currentTab === 'dashboard'
              ? 'text-[#38bdf8] font-bold'
              : 'text-[#7dd3fc]/60 hover:text-[#93c5fd]'
          }`}
        >
          <span className="material-symbols-outlined text-[22px]">dashboard</span>
          <span className="text-[10px]">Dashboard</span>
        </button>

        <button
          onClick={() => handleSelectTab('profile')}
          className={`flex flex-col items-center justify-center flex-1 py-1 transition-colors ${
            currentTab === 'profile'
              ? 'text-[#38bdf8] font-bold'
              : 'text-[#7dd3fc]/60 hover:text-[#93c5fd]'
          }`}
        >
          <span className="material-symbols-outlined text-[22px]">person</span>
          <span className="text-[10px]">โปรไฟล์</span>
        </button>
      </nav>

      {/* Universal Footer */}
      <Footer onSelectTab={handleSelectTab} />
    </div>
  );
}
