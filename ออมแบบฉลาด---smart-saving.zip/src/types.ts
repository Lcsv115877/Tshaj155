export type TabType = 'home' | 'about' | 'goals' | 'calculator' | 'dashboard' | 'knowledge' | 'quiz' | 'profile';

export interface SavingsGoal {
  id: string;
  name: string;
  icon: string;
  targetAmount: number;
  currentAmount: number;
  monthlySavings: number;
  targetDate: string;
  category?: string;
  createdAt: string;
}

export interface ExpenseBreakdown {
  income: number;
  essentialExpenses: number; // 40% - 50%
  lifestyleExpenses: number; // 20% - 30%
  savings: number; // 20% - 40%
}

export interface QuizQuestion {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

export interface Article {
  id: string;
  title: string;
  summary: string;
  content: string[];
  category: string;
  readTime: string;
  imageUrl: string;
  author?: string;
  date?: string;
}

export interface AchievementBadge {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  unlocked: boolean;
  unlockedAt?: string;
}

export interface UserProfile {
  name: string;
  role: string;
  level: number;
  progressPercent: number;
  avatarUrl: string;
  totalSaved: number;
  targetSaved: number;
  monthlyAverage: number;
  streakDays: number;
  completedQuizzes: {
    title: string;
    score: number;
    total: number;
    icon: string;
  }[];
}
