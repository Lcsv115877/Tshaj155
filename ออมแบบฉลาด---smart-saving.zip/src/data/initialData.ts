import { SavingsGoal, Article, QuizQuestion, AchievementBadge, UserProfile } from '../types';

export const INITIAL_GOALS: SavingsGoal[] = [
  {
    id: 'goal-1',
    name: 'ซื้อแท็บเล็ต',
    icon: 'devices',
    targetAmount: 10000,
    currentAmount: 4000,
    monthlySavings: 1000,
    targetDate: '2025-12-31',
    category: 'การศึกษา',
    createdAt: '2025-01-15',
  },
  {
    id: 'goal-2',
    name: 'ทริปเชียงใหม่',
    icon: 'flight_takeoff',
    targetAmount: 5000,
    currentAmount: 3750,
    monthlySavings: 1250,
    targetDate: '2025-11-20',
    category: 'ท่องเที่ยว',
    createdAt: '2025-02-01',
  },
  {
    id: 'goal-3',
    name: 'ซื้อแล็ปท็อปใหม่',
    icon: 'laptop_mac',
    targetAmount: 25000,
    currentAmount: 15000,
    monthlySavings: 2500,
    targetDate: '2026-03-30',
    category: 'การศึกษา',
    createdAt: '2024-11-10',
  },
];

export const INITIAL_ARTICLES: Article[] = [
  {
    id: 'art-1',
    title: 'เทคนิคการเก็บเงินสไตล์เด็กหอ',
    summary: 'รวมเคล็ดลับการบริหารเงินฉบับนักศึกษา ประหยัดได้โดยไม่ต้องอด อร่อยกับมาม่าได้แค่ปลายเดือน',
    category: 'การออม',
    readTime: '5 นาที',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuB4tI7ASr0-T-juNLd1ztB5dAHjAUr7HRnrlqwf1Ji9chUD5gnWwkl8b1Crk6PzNHxbGc4O4oCNoJ1R0p0RZYZYasAxjCM7cDcz-ZFImXnpQqm-9P56bxjt_Nsf6UFmy7AgBdP8l-y2JcqQL2N6JaK5Lf0-BVd4sRr-PRpmn4fkL4bCrXRQNDjbYKIQKAwpdVvTp2juEQ0UOGf862DkWEaqDwRXd6GGC4gb6ygDEykK22woiHMUWqOF',
    content: [
      'การเป็นนักศึกษาที่ต้องอยู่หอพัก มักจะมาพร้อมกับค่าใช้จ่ายจิปาถะมากมาย ทั้งค่าหอ ค่าน้ำ ค่าไฟ ค่าเดินทาง และค่าอาหาร การบริหารเงินอย่างมีแบบแผนจึงเป็นทักษะสำคัญที่จะช่วยให้คุณไม่ประสบปัญหาเงินหมดก่อนสิ้นเดือน',
      '1. แยกบัญชีใช้จ่าย: ทันทีที่ได้รับเงินโอนจากครอบครัวหรือรายได้เสริม ให้หักเงินออมไว้อย่างน้อย 10-20% ก่อนแบ่งเงินที่เหลือเป็นงวดรายสัปดาห์',
      '2. ทำอาหารทานเองบ้าง: การซื้อวัตถุดิบมาทำเมนูง่ายๆ เช่น ไข่เจียว ผัดผัก หรือข้าวต้ม ช่วยประหยัดเงินได้มากกว่าการสั่งเดลิเวอรีทุกมื้อ',
      '3. ลดรายจ่ายแฝง: สังเกตค่าชานมไข่มุก ค่ากาแฟ หรือค่าบริการสตรีมมิ่งที่ไม่ได้ดู การตัดสิ่งที่ไม่จำเป็นออกจะเพิ่มเงินออมได้หลายร้อยบาทต่อเดือน',
      '4. ใช้สิทธิ์นักศึกษา: พกบัตรนักศึกษาเพื่อรับส่วนลดค่าเดินทาง รถไฟฟ้า โรงภาพยนตร์ ซอฟต์แวร์ และพิพิธภัณฑ์เสมอ'
    ]
  },
  {
    id: 'art-2',
    title: 'กฎ 50-30-20 ทำง่าย ได้ผลจริง',
    summary: 'จัดสรรเงินรายเดือนอย่างไรให้มีเก็บ แถมยังมีเงินไปใช้จ่ายในสิ่งที่ชอบ',
    category: 'การวางแผนการเงิน',
    readTime: '4 นาที',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuA9gTEnKSSBw1k00I9TZxR8Zkq_y3N2EjSo66LJWX0gUy4WTMgxA6qSELeyzU-0J-CeTrquul6i-JgCRdXjlCPpHKiC16I0GCRZMXZbGhm-OvufK9diY_rq9qp6FCgr5y_Ygnf4CH28b7xvVKzG8xN8LQOJ9eVTLRoFkGkF1i9PC9AjPn2F5q-E-qV1d74Z45DvxgYewUN9KUdKcg04oIMI-URFRX4WiklMfFUivulv8Ig2n78B9Du3',
    content: [
      'กฎ 50-30-20 คือหลักการแบ่งสัดส่วนรายรับยอดนิยมที่นักศึกษาและคนทำงานทั่วโลกใช้สร้างวินัยทางการเงินอย่างยั่งยืน โดยแบ่งเงินออกเป็น 3 ก้อนหลักดังนี้:',
      '• 50% สำหรับความจำเป็น (Needs): ค่าเช่าหอพัก ค่าน้ำไฟ ค่าอาหารหลัก ค่าเดินทาง และค่าอุปกรณ์การเรียน',
      '• 30% สำหรับความต้องการส่วนตัว (Wants): ค่าเที่ยวสังสรรค์ ทานอาหารพิเศษ ช้อปปิ้งเสื้อผ้า และงานอดิเรก เพื่อสร้างความสุขให้ชีวิต',
      '• 20% สำหรับเงินออมและการลงทุน (Savings): เงินสำรองฉุกเฉิน กองทุน หรือเป้าหมายระยะยาว เช่น ซื้ออุปกรณ์ทำงานหรือศึกษาต่อ'
    ]
  },
  {
    id: 'art-3',
    title: 'แอปพลิเคชันช่วยจำรายรับรายจ่าย',
    summary: 'รีวิวแอปพลิเคชันเด็ดที่ควรมีติดเครื่อง ช่วยให้เรื่องจดบันทึกเป็นเรื่องสนุกและง่ายดาย',
    category: 'เทคโนโลยีทางการเงิน',
    readTime: '7 นาที',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBsD5xPDWiWfBCReZ0_-sSlZnbGCb-009Q-4_jzREnCORkfYdTZ1_O4yuDFAjKMAmv-FFwe84FQHA9TIgrS00hLDqwX175f3Yzuc-_kZqEGAZkprSl9PpPDFU_bWzCm7y442yjktAp9BNZQLk2i7sK82ktWuRkyq3HIlCZbT1jMIBDIolyvxe493NZqz_kMFzqppUHzzevcSvLa1naH7qfEid3rTHqzTTCeAHBfQTBLA9wQZ5hZIMr6',
    content: [
      'ในยุคดิจิทัล การบันทึกรายรับรายจ่ายไม่จำเป็นต้องพกสมุดเล่มหนาอีกต่อไป เพราะสมาร์ตโฟนมีแอปพลิเคชันอัจฉริยะที่ช่วยจัดหมวดหมู่อัตโนมัติและแสดงกราฟวิเคราะห์พฤติกรรมการใช้จ่ายได้อย่างแม่นยำ',
      '1. ระบบอ่านสลิปธนาคารอัตโนมัติ: บันทึกข้อมูลทันทีหลังสแกนจ่าย QR Code',
      '2. การแจ้งเตือนเมื่องบประมาณใกล้หมด: ช่วยเตือนสติก่อนใช้จ่ายเกินตัว',
      '3. การตั้งเป้าหมายเงินออม (Goal Tracking): เห็นแถบความคืบหน้ารายวัน สร้างแรงบันดาลใจในการเก็บเงิน'
    ]
  },
  {
    id: 'art-4',
    title: 'พลังของดอกเบี้ยทบต้น (Compound Interest)',
    summary: 'ทำความเข้าใจว่าทำไมการเริ่มออมเงินตั้งแต่วัยเรียนถึงสร้างความมั่งคั่งได้มากกว่าเริ่มตอนทำงาน',
    category: 'การออม',
    readTime: '6 นาที',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBp04UPpyd3piW901LVLOguiSs7TjQWnQHpJ-VDJGXYjWzRMKCfonV8lv4XwmuwHf8u6RQa6502CMuXjrowormEl1xiFs2PTVhew4t1JCuwO4OYeMO2SjomaI96UU8M2SJs74OfOMi-w-vdDQS_3TiCg-pLqXEzuqrXDZOMoWsPECd9ZPNDwF2suAGavWquP-WS9jWqfK2R8RXuHEyZgyHNFUqwwetIF8S48vmJUp3sXcD1AWGPreZV',
    content: [
      'อัลเบิร์ต ไอน์สไตน์ เคยกล่าวไว้ว่า "ดอกเบี้ยทบต้นคือสิ่งมหัศจรรย์อันดับ 8 ของโลก" เพราะมันทำให้เงินออมและผลตอบแทนของคุณงอกเงยแบบก้าวกระโดดเมื่อเวลาผ่านไป',
      'หากคุณเริ่มออมเงินเดือนละ 1,000 บาทตั้งแต่อายุ 20 ปี โดยได้รับผลตอบแทนเฉลี่ย 6% ต่อปี เมื่ออายุ 60 ปี คุณจะมีเงินเก็บมากกว่า 2,000,000 บาท ในขณะที่คนที่เริ่มออมตอนอายุ 30 ปี จะมีเงินไม่ถึง 1,000,000 บาท ทั้งที่ออมเงินเท่ากัน!'
    ]
  }
];

export const QUIZ_QUESTIONS: QuizQuestion[] = [
  {
    id: 1,
    question: '1. ข้อใดเป็นวิธีการออมเงินที่เหมาะสมที่สุดสำหรับนักศึกษา?',
    options: [
      'A. เก็บเงินทอนทั้งหมดในแต่ละวัน',
      'B. หักเงินออมทันทีที่ได้ค่าขนม',
      'C. ออมเงินเมื่อมีเงินเหลือตอนสิ้นเดือน',
      'D. นำเงินไปซื้อของที่อยากได้ก่อน ค่อยออม'
    ],
    correctAnswer: 1,
    explanation: 'หลักการ "ออมก่อนใช้" (Pay Yourself First) โดยหักเงินออมทันทีที่ได้รับค่าขนมหรือเงินเดือน เป็นวิธีสร้างวินัยที่ดีที่สุด เพราะถ้าใช้ก่อนออมมักจะไม่เหลือเงินเก็บตอนสิ้นเดือน'
  },
  {
    id: 2,
    question: '2. กฎ 50/30/20 ในการจัดการเงิน ตัวเลข 20 หมายถึงอะไร?',
    options: [
      'A. ค่าใช้จ่ายจำเป็น',
      'B. ค่าใช้จ่ายส่วนตัว',
      'C. เงินออมและการลงทุน',
      'D. เงินบริจาค'
    ],
    correctAnswer: 2,
    explanation: 'ตามกฎ 50/30/20 ตัวเลข 20% คือส่วนที่จัดสรรไว้สำหรับ "เงินออมและการลงทุน" เพื่อสร้างความมั่นคงในอนาคต'
  },
  {
    id: 3,
    question: '3. ข้อใดคือ "หนี้ดี"?',
    options: [
      'A. หนี้บัตรเครดิตเพื่อซื้อโทรศัพท์ใหม่',
      'B. กู้ยืมเงินเพื่อการศึกษา (กยศ.)',
      'C. ยืมเงินเพื่อนไปเที่ยว',
      'D. ผ่อนกระเป๋าแบรนด์เนม'
    ],
    correctAnswer: 1,
    explanation: 'หนี้ดี (Good Debt) คือหนี้สินที่ก่อให้เกิดรายได้หรือเพิ่มมูลค่าทักษะในอนาคต เช่น หนี้เพื่อการศึกษาหรือการลงทุนพัฒนาตนเอง'
  },
  {
    id: 4,
    question: '4. ดอกเบี้ยทบต้น (Compound Interest) มีประโยชน์อย่างไร?',
    options: [
      'A. ทำให้ได้เงินคืนเร็วขึ้น',
      'B. ทำให้เงินต้นงอกเงยแบบทวีคูณเมื่อเวลาผ่านไป',
      'C. ลดภาษีที่ต้องจ่าย',
      'D. ทำให้ไม่ต้องเสียค่าธรรมเนียมธนาคาร'
    ],
    correctAnswer: 1,
    explanation: 'ดอกเบี้ยทบต้นจะนำดอกเบี้ยที่ได้รับไปรวมเข้ากับเงินต้น แล้วคำนวณดอกเบี้ยในงวดถัดไป ทำให้เงินเติบโตแบบ Exponential เมื่อระยะเวลายาวนานขึ้น'
  },
  {
    id: 5,
    question: '5. หากมีเป้าหมายระยะสั้น (1-3 เดือน) ควรเก็บเงินไว้ที่ไหน?',
    options: [
      'A. ซื้อหุ้น',
      'B. ซื้อกองทุนรวมระยะยาว',
      'C. บัญชีออมทรัพย์หรือฝากประจำระยะสั้น',
      'D. เก็บไว้ใต้หมอน'
    ],
    correctAnswer: 2,
    explanation: 'เป้าหมายระยะสั้นควรเน้นสภาพคล่องสูงและความเสี่ยงต่ำ บัญชีเงินฝากออมทรัพย์ดิจิทัลดอกเบี้ยสูงหรือฝากประจำระยะสั้นจึงเหมาะสมที่สุด'
  }
];

export const INITIAL_BADGES: AchievementBadge[] = [
  {
    id: 'badge-1',
    title: 'ก้าวแรก',
    description: 'เริ่มต้นสร้างเป้าหมายการออมแรกของคุณ',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCycZQ0S22kCTReoq6N7y-16ydwGQK7SM4vgdWsPl5qgEzga0sxtp5NgjTQAtGHPW-mttDNBGMdv878XF-F9xiO4pf6ayJdnNLHTAdmzljRePH7evNGsJhNImIESJg9PN5fOODzzTg-lrTGi0EI0WxZ61AvLlUMe8T3clktfUHkt9r4Ikd5RoAEgEiUWfXXCmEx17T7x-eIqyHauYw10RnLWDvGWzQovzkIo9DwPHKhJadBDvhvz4dI',
    unlocked: true,
    unlockedAt: '2025-01-15'
  },
  {
    id: 'badge-2',
    title: 'ออมสม่ำเสมอ',
    description: 'ออมเงินต่อเนื่องครบ 7 วัน',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDwGo0lfhJyoV0lWpD0c1ApZ4VuI_CgvwLmkMSdBokX2ENCNXXBB1Iupp1592q7pUkVMVqiMAA6-I7qPXgXK_zKuSrasbgvqCB6c_3TxjD_cH4M3jdYj1oZRTiTWvEtYJOCqkzWFCmdkbyvMTFol3_6TROQ0Zs7jWumjOEiSr5B76ABnOrd3NIjec6krKS6WCDbHuAVa_GwTc1-lYjeSK6nh3MWb3dJcu6_TuChF8OMBo_514BAqpit',
    unlocked: true,
    unlockedAt: '2025-02-10'
  },
  {
    id: 'badge-3',
    title: 'พิชิตเป้าหมาย',
    description: 'บรรลุเป้าหมายการออมเงิน 1 รายการสำเร็จ',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBgEdtz1FACMaLoD_j2FWzBxKxp-15_29x9F-Du2BdbqM5J3JUW0bE7NaR7nvf5SRiCZDwktRmCcTJuYdkuBvm7Ip3Rl0eyBBjz_pOKhiH6wjLYr-4U-ICiLg_-SkLfeUz_9m9NXwfq6IZPwzm7hzgXcfSST569u-h_DIq55iSHR0mI-bkLeDF7v2Cl7j0abOJ3fxnsBDp8EtLeBJBOaqHiGpEOxXANpuWFFdM_O5lc2kD7_5Jac5OF',
    unlocked: false
  },
  {
    id: 'badge-4',
    title: 'ผู้รอบรู้',
    description: 'ทำแบบทดสอบความรู้การเงินได้เต็ม 5/5',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBmA2eUACjvaA9QU5-OtSpx0F33D3vyP-Z03M_4w4qC02IJB3HwfFe7CpBs6cKt0tWhaWeYFm1J-z0A6Szmj2RrSQPHazq99KJXTu7fnxUn0j4hgCtVmT0IN2b6oSl6yTSbyQcUrBkDPI0Ik4TNNnmiqG1TQlW8OYNooeoYTiPbV9_SkcWanAmdLzjgoRRcs4Jd5jANwLaHPxwJhQfD9eAKdEUBiu8DXZSft_eidSPAmowfoviiXuQw',
    unlocked: false
  }
];

export const INITIAL_PROFILE: UserProfile = {
  name: 'กิตติพงษ์ ใจดี',
  role: 'นักศึกษามหาวิทยาลัย - ผู้เริ่มต้นออม',
  level: 3,
  progressPercent: 75,
  avatarUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCNhDtP2cudT8GbNLU-t6bRS6uxnUpXCbqw1I-FTnzECUGMQjkS09q8OYKUYV0P69vZL_8TMHHXfNSF4DwHTowzG3DT40yPfqP9-bsHT9oEcksFV0Jv5zbo4Mh39tZnm6a9As-d3HDPy6A5L3wKMGnugWJw3U-lZ91zrIOfy77w6hjJMeu6xAwQoOF8GBA45y8CeQZSBDy2QfCnKlAmVMlpueKnHu-Q_gdWpPtamwGD4rRqGp-MKQPH',
  totalSaved: 15450,
  targetSaved: 20000,
  monthlyAverage: 2500,
  streakDays: 14,
  completedQuizzes: [
    {
      title: 'พื้นฐานการจัดการเงิน',
      score: 9,
      total: 10,
      icon: 'quiz'
    },
    {
      title: 'การลงทุนเบื้องต้น',
      score: 7,
      total: 10,
      icon: 'show_chart'
    }
  ]
};

export const MONTHLY_SAVINGS_HISTORY = [
  { month: 'ม.ค.', amount: 1500, heightPercent: 40 },
  { month: 'ก.พ.', amount: 2200, heightPercent: 55 },
  { month: 'มี.ค.', amount: 2800, heightPercent: 70 },
  { month: 'เม.ย.', amount: 1200, heightPercent: 35 },
  { month: 'พ.ค.', amount: 3100, heightPercent: 80 },
  { month: 'มิ.ย.', amount: 3500, heightPercent: 100 },
];
